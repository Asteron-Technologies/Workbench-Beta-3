#!/usr/bin/env python3
"""
Asteron Workbench — Device Creator v2.1
Full visual .adev editor with pin rotation, image sizing persistence, and complete control.
"""
import sys,os,json,math,copy,base64,re as _re,time as _time,tempfile as _tf
from pathlib import Path
from PyQt5.QtWidgets import (
    QApplication,QMainWindow,QWidget,QVBoxLayout,QHBoxLayout,QLabel,QPushButton,
    QLineEdit,QSpinBox,QDoubleSpinBox,QComboBox,QCheckBox,QPlainTextEdit,QTextEdit,
    QTabWidget,QStackedWidget,QListWidget,QScrollArea,QFileDialog,QMessageBox,
    QColorDialog,QFrame,QSizePolicy,QStatusBar,QSlider,QMenu,QGridLayout)
from PyQt5.QtCore import Qt,QTimer,QPointF,QRectF,pyqtSignal,QPoint,QSize,QSettings
from PyQt5.QtGui import (
    QPainter,QColor,QFont,QPen,QBrush,QRadialGradient,QImage,QPalette,
    QFontMetrics,QPainterPath,QPixmap,QCursor,QPolygonF,QIcon,QFontDatabase)

class T:
    bg="#0c0c0e";panel="#131316";panelAlt="#18181c";surface="#1c1c22";surfHov="#242430"
    border="#222230";borderL="#2a2a38"
    blue="#4a9eff";blueDim="#1a2844";red="#ff4d4d";redDim="#3a1818"
    green="#44dd66";greenDim="#163322";orange="#ff9933";orangeDim="#332211";purple="#b07aff"
    text="#d4d4dc";textSec="#8888a0";textMut="#505068";MONO="Consolas";UI="Segoe UI";R=4

def _resolve_fonts():
    try:
        db=QFontDatabase();avail=db.families()
        for name in ["Consolas","SF Mono","Menlo","DejaVu Sans Mono","Liberation Mono","Courier New","monospace"]:
            if name in avail:T.MONO=name;break
        for name in ["Segoe UI","SF Pro Display","Helvetica Neue","Ubuntu","Noto Sans","Arial","sans-serif"]:
            if name in avail:T.UI=name;break
    except Exception:
        pass

def _validate_device_id(text):
    return bool(_re.match(r'^[a-zA-Z][a-zA-Z0-9_]*$',text)) if text else False

PIN_CLR={"digital":T.blue,"analog":T.green,"power":T.red,"ground":"#666680","gnd":"#666680",
    "signal":T.orange,"passive":"#808090","i2c_sda":T.orange,"i2c_scl":T.orange,
    "spi_mosi":T.blue,"spi_miso":T.blue,"spi_sck":T.blue,"serial_tx":T.purple,"serial_rx":T.purple}
PIN_TYPES=["digital","analog","power","ground","signal","passive","i2c_sda","i2c_scl",
    "spi_mosi","spi_miso","spi_sck","serial_tx","serial_rx"]
PIN_DIRS=["io","in","out"];PIN_SIDES=["left","right","top","bottom"]
PIN_SHAPES=["circle","square","diamond","triangle"]
CATEGORIES=["Boards","Output","Display","Input","Sensor","Passive","Communication","Other"]

SS=("QMainWindow{background:"+T.bg+"}"
"QStatusBar{background:"+T.panel+";color:"+T.textMut+";border-top:1px solid "+T.border+"}"
"QTabWidget::pane{background:"+T.panel+";border:none;border-top:1px solid "+T.border+"}"
"QTabBar::tab{background:"+T.panel+";color:"+T.textMut+";padding:8px 18px;border-bottom:2px solid transparent;font-family:"+T.MONO+";font-size:11px}"
"QTabBar::tab:selected{color:"+T.orange+";border-bottom-color:"+T.orange+"}"
"QTabBar::tab:hover{color:"+T.text+"}"
"QPushButton{background:"+T.surface+";color:"+T.text+";border:1px solid "+T.border+";border-radius:4px;padding:5px 12px;font-size:11px;font-weight:bold}"
"QPushButton:hover{background:"+T.surfHov+";border-color:"+T.blue+"}"
"QLineEdit,QSpinBox,QDoubleSpinBox,QComboBox{background:"+T.bg+";color:"+T.text+";border:1px solid "+T.border+";border-radius:4px;padding:4px 8px;font-size:11px}"
"QLineEdit:focus,QSpinBox:focus,QDoubleSpinBox:focus{border-color:"+T.orange+"}"
"QComboBox::drop-down{border:none;padding-right:8px}"
"QComboBox QAbstractItemView{background:"+T.surface+";color:"+T.text+";border:1px solid "+T.border+";selection-background-color:"+T.orange+"}"
"QPlainTextEdit,QTextEdit{background:"+T.bg+";color:#c8c8dc;border:none;font-family:"+T.MONO+";font-size:12px}"
"QLabel{color:"+T.text+"}"
"QScrollBar:vertical{background:"+T.bg+";width:8px}"
"QScrollBar::handle:vertical{background:"+T.border+";min-height:30px;border-radius:4px}"
"QScrollBar::add-line:vertical,QScrollBar::sub-line:vertical{height:0}"
"QScrollBar:horizontal{background:"+T.bg+";height:8px}"
"QScrollBar::handle:horizontal{background:"+T.border+";min-width:30px;border-radius:4px}"
"QScrollBar::add-line:horizontal,QScrollBar::sub-line:horizontal{width:0}"
"QListWidget{background:"+T.bg+";color:"+T.text+";border:1px solid "+T.border+";border-radius:4px;font-size:11px;outline:none}"
"QListWidget::item{padding:4px 8px}"
"QListWidget::item:selected{background:"+T.orangeDim+";color:"+T.orange+"}"
"QListWidget::item:hover{background:"+T.surfHov+"}"
"QCheckBox{color:"+T.textSec+";spacing:6px}"
"QCheckBox::indicator{width:14px;height:14px;border:1px solid "+T.border+";border-radius:3px;background:"+T.bg+"}"
"QCheckBox::indicator:checked{background:"+T.green+";border-color:"+T.green+"}"
"QSlider::groove:horizontal{background:"+T.border+";height:4px;border-radius:2px}"
"QSlider::handle:horizontal{background:"+T.orange+";width:14px;height:14px;margin:-5px 0;border-radius:7px}"
"QSlider::sub-page:horizontal{background:"+T.orange+";border-radius:2px}")

def _lbl(t,c=None):
    l=QLabel(t);l.setFont(QFont(T.MONO,9,QFont.Bold));l.setStyleSheet("color:"+(c or T.textMut)+";letter-spacing:1.5px;margin-top:4px");return l
def make_field(lb,w,lay):lay.addWidget(_lbl(lb));lay.addWidget(w);return w
def make_spin(v,lo,hi,lay,lb):
    s=QSpinBox();s.setRange(lo,hi);s.setValue(v);s.setFont(QFont(T.MONO,11));return make_field(lb,s,lay)
def make_combo(its,cur,lay,lb):
    c=QComboBox();c.addItems(its)
    if cur in its:c.setCurrentText(cur)
    c.setFont(QFont(T.MONO,11));return make_field(lb,c,lay)
def make_line(t,lay,lb,mono=False):
    e=QLineEdit(t);e.setFont(QFont(T.MONO if mono else T.UI,11));return make_field(lb,e,lay)
def _sep():f=QFrame();f.setFrameShape(QFrame.HLine);f.setStyleSheet("color:"+T.border);return f
def _vsep():f=QFrame();f.setFrameShape(QFrame.VLine);f.setStyleSheet("color:"+T.border);return f
def _abtn(t,c,fn):
    dm={T.blue:T.blueDim,T.red:T.redDim,T.green:T.greenDim,T.orange:T.orangeDim}.get(c,T.blueDim)
    b=QPushButton(t);b.setStyleSheet("QPushButton{background:"+dm+";color:"+c+";border:1px solid "+c+"44;border-radius:4px;padding:6px 14px;font-weight:bold}QPushButton:hover{background:"+c+";color:#000}");b.clicked.connect(fn);return b
def _make_icon():
    pm=QPixmap(32,32);pm.fill(QColor(T.bg));p=QPainter(pm);p.setRenderHint(QPainter.Antialiasing)
    for(cx,cy),cl in zip([(10,10),(22,10),(10,22),(22,22)],[T.blue,T.red,T.green,T.orange]):
        p.setBrush(QBrush(QColor(cl)));p.setPen(Qt.NoPen);p.drawEllipse(QPointF(cx,cy),4,4)
    p.end();return QIcon(pm)

class UndoStack:
    def __init__(s,mx=80):s._s=[];s._i=-1;s._m=mx
    def push(s,st):
        s._s=s._s[:s._i+1];s._s.append(copy.deepcopy(st))
        if len(s._s)>s._m:s._s.pop(0)
        s._i=len(s._s)-1
    def undo(s):
        if s._i>0:s._i-=1;return copy.deepcopy(s._s[s._i])
        return None
    def redo(s):
        if s._i<len(s._s)-1:s._i+=1;return copy.deepcopy(s._s[s._i])
        return None
    def can_undo(s):return s._i>0
    def can_redo(s):return s._i<len(s._s)-1

def draw_pin(p,x,y,r,sh,rot,fill,bpen):
    p.setBrush(QBrush(fill));p.setPen(bpen);p.save();p.translate(x,y)
    if rot:p.rotate(rot)
    if sh=="square":p.drawRect(QRectF(-r,-r,r*2,r*2))
    elif sh=="diamond":p.drawPolygon(QPolygonF([QPointF(0,-r),QPointF(r,0),QPointF(0,r),QPointF(-r,0)]))
    elif sh=="triangle":p.drawPolygon(QPolygonF([QPointF(0,-r),QPointF(r,r),QPointF(-r,r)]))
    else:p.drawEllipse(QPointF(0,0),r,r)
    p.restore()

def draw_pin_stub(p,x,y,side,rot,clr,length=14):
    base={"left":180,"right":0,"top":270,"bottom":90}
    angle=base.get(side,0)+rot;rad=math.radians(angle)
    ex=x+math.cos(rad)*length;ey=y+math.sin(rad)*length
    p.setPen(QPen(QColor(clr.red(),clr.green(),clr.blue(),120),1.5))
    p.drawLine(QPointF(x,y),QPointF(ex,ey))

# ═══════════════════ VISUAL CANVAS ═══════════════════
class VisualCanvas(QWidget):
    pinPlaced=pyqtSignal(int,int);ledPlaced=pyqtSignal(int,int);displayDrawn=pyqtSignal(int,int,int,int)
    itemClicked=pyqtSignal(str,int);itemMoved=pyqtSignal(str,int,int,int);mouseAt=pyqtSignal(int,int)

    def __init__(s,mw):
        super().__init__();s.mw=mw;s.setMouseTracking(True);s.setFocusPolicy(Qt.StrongFocus)
        s.tool="select";s.zoom=2.0;s.pan=QPointF(0,0)
        s.image=None;s.image_path=None;s.img_opacity=1.0
        s.img_w=0;s.img_h=0;s.img_ox=0;s.img_oy=0
        s.grid_on=True;s.grid_snap=True;s.grid_size=8
        s._di=None;s._do=None;s._ds=None;s._de=None
        s._panning=False;s._ps=None;s._pc=None;s._space=False
        s._img_drag=False;s._img_do=None

    def snap(s,v):
        if s.grid_snap and s.grid_size>=2:return round(v/s.grid_size)*s.grid_size
        return round(v)
    def _td(s,wp):return(wp.x()-s.pan.x())/s.zoom,(wp.y()-s.pan.y())/s.zoom
    def _fa(s,dx,dy):
        for i,l in enumerate(s.mw.leds):
            if math.hypot(dx-l["x"],dy-l["y"])<l.get("radius",8)+3:return("led",i)
        for i,p in enumerate(s.mw.pins):
            if math.hypot(dx-p["x"],dy-p["y"])<p.get("size",4)+4:return("pin",i)
        return None
    def center_view(s):
        dw,dh=s.mw.dev_w.value(),s.mw.dev_h.value()
        s.pan=QPointF((s.width()-dw*s.zoom)/2,(s.height()-dh*s.zoom)/2);s.update()
    def set_image(s,img,path):
        s.image=img;s.image_path=path
        if img and not img.isNull():s.img_w=img.width();s.img_h=img.height()
        s.update()
    def clear_image(s):s.image=None;s.image_path=None;s.img_w=0;s.img_h=0;s.img_ox=0;s.img_oy=0;s.update()

    def mousePressEvent(s,e):
        dx,dy=s._td(e.pos())
        if e.button()==Qt.MiddleButton or(e.button()==Qt.LeftButton and s._space):
            s._panning=True;s._ps=e.pos();s._pc=QPointF(s.pan);s.setCursor(Qt.ClosedHandCursor);return
        if e.button()==Qt.RightButton:s._ctx(e.pos(),dx,dy);return
        if e.button()!=Qt.LeftButton:return
        if s.tool=="pin":s.pinPlaced.emit(int(s.snap(dx)),int(s.snap(dy)))
        elif s.tool=="led":s.ledPlaced.emit(int(s.snap(dx)),int(s.snap(dy)))
        elif s.tool=="display":s._ds=(dx,dy);s._de=None
        elif s.tool=="move_image":s._img_drag=True;s._img_do=(dx-s.img_ox,dy-s.img_oy)
        elif s.tool=="select":
            h=s._fa(dx,dy)
            if h:
                t,i=h;s.itemClicked.emit(t,i)
                items=s.mw.pins if t=="pin" else s.mw.leds
                if 0<=i<len(items):it=items[i];s._di=(t,i);s._do=(dx-it["x"],dy-it["y"])
            else:s.itemClicked.emit("none",-1)

    def mouseMoveEvent(s,e):
        dx,dy=s._td(e.pos());s.mouseAt.emit(int(dx),int(dy))
        if s._panning and s._ps:d=e.pos()-s._ps;s.pan=s._pc+QPointF(d.x(),d.y());s.update();return
        if s._ds:s._de=(dx,dy);s.update();return
        if s._img_drag and s._img_do:
            ox,oy=s._img_do;s.img_ox=int(s.snap(dx-ox));s.img_oy=int(s.snap(dy-oy))
            s.mw._sync_img_offset();s.update();return
        if s._di and s._do:
            ox,oy=s._do;nx,ny=s.snap(dx-ox),s.snap(dy-oy);t,i=s._di
            items=s.mw.pins if t=="pin" else s.mw.leds
            if 0<=i<len(items):items[i]["x"]=int(nx);items[i]["y"]=int(ny)
            s.update();return
        if s.tool in("pin","led","display"):s.setCursor(Qt.CrossCursor)
        elif s.tool=="move_image":s.setCursor(Qt.SizeAllCursor)
        else:s.setCursor(Qt.SizeAllCursor if s._fa(dx,dy) else Qt.ArrowCursor)
        s.update()

    def mouseReleaseEvent(s,e):
        if s._panning:s._panning=False;s.setCursor(Qt.ArrowCursor);return
        if s._img_drag:s._img_drag=False;s._img_do=None;s.mw._save_undo();s.mw._mark_unsaved();return
        if s._di:
            t,i=s._di;items=s.mw.pins if t=="pin" else s.mw.leds
            if 0<=i<len(items):it=items[i];s.itemMoved.emit(t,i,it["x"],it["y"])
            s._di=None;s._do=None;s.update();return
        if s.tool=="display" and s._ds and s._de:
            x0,y0=s._ds;x1,y1=s._de;rx,ry=min(x0,x1),min(y0,y1);rw,rh=abs(x1-x0),abs(y1-y0)
            if rw>4 and rh>4:s.displayDrawn.emit(int(rx),int(ry),int(rw),int(rh))
            s._ds=None;s._de=None;s.update()

    def wheelEvent(s,e):
        old=s.zoom;f=1.15 if e.angleDelta().y()>0 else 1/1.15;nz=max(0.5,min(10.0,s.zoom*f))
        mx,my=e.pos().x(),e.pos().y()
        s.pan=QPointF(mx-(mx-s.pan.x())*nz/old,my-(my-s.pan.y())*nz/old);s.zoom=nz;s.update()

    def keyPressEvent(s,e):
        if e.key()==Qt.Key_Space:s._space=True;s.setCursor(Qt.OpenHandCursor)
        elif e.key()==Qt.Key_G:s.mw._toggle_grid()
        elif e.key() in(Qt.Key_Delete,Qt.Key_Backspace):s.mw._delete_selected()
        elif e.key()==Qt.Key_Escape:s.mw._deselect();s.tool="select";s.mw._sync_tools()
        elif e.key()==Qt.Key_R and s.mw.sel_type=="pin":s.mw._rotate_selected_pin()
        elif e.key()==Qt.Key_1:s.mw._set_vtool("select")
        elif e.key()==Qt.Key_2:s.mw._set_vtool("pin")
        elif e.key()==Qt.Key_3:s.mw._set_vtool("led")
        elif e.key()==Qt.Key_4:s.mw._set_vtool("display")
        elif e.key()==Qt.Key_5:s.mw._set_vtool("move_image")
        elif e.key()==Qt.Key_Home:s.center_view()
        else:e.ignore()
    def keyReleaseEvent(s,e):
        if e.key()==Qt.Key_Space:s._space=False;s.setCursor(Qt.ArrowCursor)

    def _ctx(s,pos,dx,dy):
        h=s._fa(dx,dy);m=QMenu(s)
        m.setStyleSheet("QMenu{background:"+T.surface+";color:"+T.text+";border:1px solid "+T.border+";border-radius:4px;padding:4px}QMenu::item{padding:6px 20px}QMenu::item:selected{background:"+T.orange+";color:#000}")
        if h:
            t,i=h;nm="Pin" if t=="pin" else "LED";s.itemClicked.emit(t,i)
            if t=="pin":
                rm=m.addMenu("Rotate Pin")
                for deg in[0,90,180,270]:rm.addAction(f"{deg}\u00b0",lambda d=deg:s.mw._set_pin_rotation(i,d))
                m.addAction("Flip Side",lambda:s.mw._flip_pin_side(i))
            m.addAction(f"Duplicate {nm}",lambda:s.mw._dup_item(t,i))
            m.addAction(f"Delete {nm}",lambda:s.mw._del_item(t,i))
        else:
            m.addAction("Place Pin Here",lambda:s.pinPlaced.emit(int(s.snap(dx)),int(s.snap(dy))))
            m.addAction("Place LED Here",lambda:s.ledPlaced.emit(int(s.snap(dx)),int(s.snap(dy))))
            m.addSeparator();m.addAction("Reset View (Home)",s.center_view)
        m.exec_(s.mapToGlobal(pos))

    def paintEvent(s,event):
        mw=s.mw;dw,dh=mw.dev_w.value(),mw.dev_h.value()
        p=QPainter(s);p.setRenderHint(QPainter.Antialiasing);p.setRenderHint(QPainter.SmoothPixmapTransform)
        p.fillRect(s.rect(),QColor("#08080a"));p.save();p.translate(s.pan);p.scale(s.zoom,s.zoom)
        if s.grid_on and s.grid_size>=2:
            gs=s.grid_size;p.setPen(QPen(QColor("#ffffff0a"),0.5))
            for gx in range(0,dw+1,gs):p.drawLine(QPointF(gx,0),QPointF(gx,dh))
            for gy in range(0,dh+1,gs):p.drawLine(QPointF(0,gy),QPointF(dw,gy))
        p.setPen(QPen(QColor(T.orange+"44"),1,Qt.DashLine));p.setBrush(Qt.NoBrush)
        p.drawRect(QRectF(-0.5,-0.5,dw+1,dh+1))
        if s.image and not s.image.isNull():
            p.setOpacity(s.img_opacity)
            iw=s.img_w if s.img_w>0 else s.image.width();ih=s.img_h if s.img_h>0 else s.image.height()
            p.drawImage(QRectF(s.img_ox,s.img_oy,iw,ih),s.image);p.setOpacity(1.0)
            if s.tool=="move_image":
                p.setPen(QPen(QColor(T.blue+"66"),1,Qt.DashLine));p.setBrush(Qt.NoBrush)
                p.drawRect(QRectF(s.img_ox,s.img_oy,iw,ih))
        else:
            p.fillRect(0,0,dw,dh,QColor(mw.dev_color.text()))
            p.setPen(QColor(T.textMut));p.setFont(QFont(T.MONO,10))
            p.drawText(QRectF(0,0,dw,dh),Qt.AlignCenter,"No image\nUpload one")
        if mw.has_display.isChecked():
            dr=mw.disp_region;p.fillRect(QRectF(dr["x"],dr["y"],dr["w"],dr["h"]),QColor(mw.disp_bg.text()))
            p.setPen(QPen(QColor(T.green),1,Qt.DashLine));p.setBrush(Qt.NoBrush)
            p.drawRect(QRectF(dr["x"],dr["y"],dr["w"],dr["h"]))
            p.setPen(QColor(T.green+"aa"));p.setFont(QFont(T.MONO,7))
            p.drawText(QRectF(dr["x"],dr["y"],dr["w"],dr["h"]),Qt.AlignCenter,f'{mw.disp_px_w.value()}x{mw.disp_px_h.value()}')
        if s._ds and s._de:
            x0,y0=s._ds;x1,y1=s._de;p.setPen(QPen(QColor(T.green),1.5,Qt.DashLine))
            p.setBrush(QBrush(QColor(68,221,102,30)));p.drawRect(QRectF(min(x0,x1),min(y0,y1),abs(x1-x0),abs(y1-y0)))
        ts=mw.test_state if mw.test_running else {}
        for i,led in enumerate(mw.leds):
            sv=led.get("state_var","");ov=led.get("on_value",True);ion=mw.test_running and ts.get(sv)==ov
            lx,ly=led["x"],led["y"];lr=led.get("radius",8);lc=QColor(led.get("color","#ff3344"))
            isel=mw.sel_type=="led" and mw.sel_idx==i
            if ion:
                g=QRadialGradient(lx,ly,lr*3);g.setColorAt(0,QColor(lc.red(),lc.green(),lc.blue(),200))
                g.setColorAt(1,QColor(lc.red(),lc.green(),lc.blue(),0));p.setBrush(QBrush(g));p.setPen(Qt.NoPen)
                p.drawEllipse(QPointF(lx,ly),lr*3,lr*3)
            fl=QColor(lc) if ion else QColor(lc.red()//4,lc.green()//4,lc.blue()//4,120)
            p.setBrush(QBrush(fl))
            if isel:p.setPen(QPen(QColor(T.orange),2.5))
            else:p.setPen(QPen(QColor(lc.red()//2,lc.green()//2,lc.blue()//2),1))
            p.drawEllipse(QPointF(lx,ly),lr,lr)
            if isel:p.setPen(QPen(QColor(T.orange),1,Qt.DashLine));p.setBrush(Qt.NoBrush);p.drawRect(QRectF(lx-lr-4,ly-lr-4,lr*2+8,lr*2+8))
            p.setPen(QColor(T.text));p.setFont(QFont(T.MONO,6,QFont.Bold));p.drawText(QPointF(lx-10,ly-lr-4),led.get("label","?"))
        mdx,mdy=s._td(s.mapFromGlobal(QCursor.pos()))
        for i,pin in enumerate(mw.pins):
            pc=QColor(PIN_CLR.get(pin.get("type","digital"),"#808090"))
            isel=mw.sel_type=="pin" and mw.sel_idx==i;pr=pin.get("size",4);sh=pin.get("shape","circle")
            rot=pin.get("rotation",0);dist=math.hypot(mdx-pin["x"],mdy-pin["y"])
            ihov=dist<pr+4 and s.underMouse();dr2=pr+3 if isel else pr+2 if ihov else pr
            if isel:fc=QColor("#ffffff");bp=QPen(QColor(T.orange),2.5)
            elif ihov:fc=QColor(T.blue);bp=QPen(QColor(T.blue+"88"),1.5)
            else:fc=pc;bp=QPen(QColor(pc.red(),pc.green(),pc.blue(),60),1)
            draw_pin_stub(p,pin["x"],pin["y"],pin.get("side","left"),rot,pc)
            draw_pin(p,pin["x"],pin["y"],dr2,sh,rot,fc,bp)
            if isel:p.setPen(QPen(QColor(T.orange),1,Qt.DashLine));p.setBrush(Qt.NoBrush);p.drawRect(QRectF(pin["x"]-dr2-4,pin["y"]-dr2-4,dr2*2+8,dr2*2+8))
            p.setPen(QColor(T.text));p.setFont(QFont(T.MONO,6,QFont.Bold))
            p.drawText(QPointF(pin["x"]-10,pin["y"]-pr-5),pin.get("label","?"))
            if rot!=0:
                p.setPen(QColor(T.orange+"88"));p.setFont(QFont(T.MONO,5))
                p.drawText(QPointF(pin["x"]+pr+3,pin["y"]+3),f"{rot}\u00b0")
            if ihov and not s._di:
                sd=pin.get("side","left")[0].upper()
                txt=f'{pin.get("label","?")} ({pin.get("type","?")}) [{sh} r{pr}] {sd} {rot}\u00b0'
                p.setFont(QFont(T.MONO,7,QFont.Bold));fm=p.fontMetrics();tw=fm.horizontalAdvance(txt)+14
                p.setBrush(QBrush(QColor(0,0,0,230)));p.setPen(Qt.NoPen)
                p.drawRoundedRect(QRectF(pin["x"]-tw/2,pin["y"]-34,tw,18),4,4)
                p.setPen(QColor("#fff"));p.drawText(QRectF(pin["x"]-tw/2,pin["y"]-34,tw,18),Qt.AlignCenter,txt)
        if s.tool in("pin","led") and s.underMouse():
            sx,sy=s.snap(mdx),s.snap(mdy);p.setPen(QPen(QColor(T.orange+"66"),0.8,Qt.DashLine))
            p.drawLine(QPointF(sx,0),QPointF(sx,dh));p.drawLine(QPointF(0,sy),QPointF(dw,sy))
            p.setBrush(QBrush(QColor(T.orange+"44")));p.setPen(QPen(QColor(T.orange),1.5,Qt.DashLine))
            p.drawEllipse(QPointF(sx,sy),6,6)
        p.restore()
        p.setPen(QColor(T.textMut));p.setFont(QFont(T.MONO,9));p.drawText(8,s.height()-8,f"{s.zoom:.1f}x")
        if s.grid_on and s.grid_snap:p.drawText(60,s.height()-8,f"grid:{s.grid_size}px")
        elif not s.grid_on:p.drawText(60,s.height()-8,"grid:OFF")
        hints={"pin":"Click to place pin (R=rotate sel.)","led":"Click to place LED","display":"Drag rectangle for display region","move_image":"Drag to reposition image"}
        if s.tool in hints:
            p.setPen(QColor(T.orange+"aa"));p.setFont(QFont(T.MONO,8));p.drawText(8,16,hints[s.tool])
        p.end()

DEFAULT_EMU=json.dumps({"type":"active","state_vars":{"led_on":False,"brightness":0},"rules":[{"trigger":"pin_high","pin":"anode","action":"set_state","target":"led_on","value":True},{"trigger":"pin_low","pin":"anode","action":"set_state","target":"led_on","value":False}],"properties":{"forward_voltage":2.0,"max_current_ma":20}},indent=2)

# ═══════════════════ MAIN WINDOW ═══════════════════
class DeviceCreator(QMainWindow):
    def __init__(s):
        super().__init__();s.setWindowIcon(_make_icon())
        s.setMinimumSize(1050,680);s.resize(1380,850);s.setStyleSheet(SS)
        s.pins=[];s.leds=[];s.disp_region={"x":10,"y":10,"w":80,"h":40};s.image_b64=None
        s.sel_type="none";s.sel_idx=-1;s.test_running=False;s.test_state={};s.test_tick=0
        s.undo=UndoStack();s.test_timer=QTimer();s.test_timer.setInterval(500);s.test_timer.timeout.connect(s._test_tick)
        s._unsaved=False;s._last_export_path=None
        s._autosave_dir=Path(_tf.gettempdir())/"asteron_workbench"
        s._autosave_timer=QTimer();s._autosave_timer.setInterval(60000)
        s._autosave_timer.timeout.connect(s._autosave);s._autosave_timer.start()
        s._settings=QSettings("AsteronTech","DeviceCreator")
        s._build_ui()
        sb=s.statusBar();s.st_msg=QLabel("Ready");s.st_msg.setFont(QFont(T.MONO,10))
        s.st_coord=QLabel("(0, 0)");s.st_coord.setFont(QFont(T.MONO,10));s.st_coord.setStyleSheet("color:"+T.textMut)
        s.st_undo=QLabel("");s.st_undo.setFont(QFont(T.MONO,9));s.st_undo.setStyleSheet("color:"+T.textMut)
        sb.addWidget(s.st_msg,1);sb.addPermanentWidget(s.st_undo);sb.addPermanentWidget(s.st_coord)
        s._save_undo();s._update_title()
        QTimer.singleShot(500,s._check_autosave)

    def _mark_unsaved(s):s._unsaved=True;s._update_title()
    def _update_title(s):
        nm=Path(s._last_export_path).stem if s._last_export_path else "Untitled"
        d=" \u2022" if s._unsaved else ""
        s.setWindowTitle(f"Asteron Workbench \u2014 Device Creator \u2014 {nm}{d}")
    def closeEvent(s,event):
        if s._unsaved:
            reply=QMessageBox.question(s,"Unsaved Changes","You have unsaved changes. Export before closing?",
                QMessageBox.Save|QMessageBox.Discard|QMessageBox.Cancel,QMessageBox.Save)
            if reply==QMessageBox.Save:s._export();event.accept()
            elif reply==QMessageBox.Discard:event.accept()
            else:event.ignore()
        else:event.accept()
    def _autosave(s):
        if not s._unsaved:return
        try:
            s._autosave_dir.mkdir(exist_ok=True);ad=s._build_adev()
            if ad:
                with open(s._autosave_dir/"autosave_creator.adev","w",encoding="utf-8") as f:json.dump(ad,f)
        except Exception:pass
    def _check_autosave(s):
        af=s._autosave_dir/"autosave_creator.adev"
        if af.exists():
            age=_time.time()-af.stat().st_mtime
            if age<3600:
                reply=QMessageBox.question(s,"Recover Auto-Save",f"Found auto-saved device ({int(age/60)} min old). Recover?",QMessageBox.Yes|QMessageBox.No)
                if reply==QMessageBox.Yes:
                    try:
                        with open(af,"r",encoding="utf-8") as fh:data=json.load(fh)
                        s._apply_import(data);s._unsaved=True;s._update_title()
                    except Exception:pass
    def _add_recent(s,path):
        recents=s._settings.value("recent_files",[],type=list)
        if path in recents:recents.remove(path)
        recents.insert(0,path);s._settings.setValue("recent_files",recents[:8])
    def _check_pin_bounds(s,x,y):
        dw,dh=s.dev_w.value(),s.dev_h.value()
        if x<-10 or y<-10 or x>dw+10 or y>dh+10:
            s.st_msg.setText("\u26a0 Pin outside device bounds!");s.st_msg.setStyleSheet("color:"+T.orange)
            QTimer.singleShot(3000,lambda:(s.st_msg.setText("Ready"),s.st_msg.setStyleSheet("color:"+T.text)))
    def _snap_to_edge(s,x,y):
        dw,dh=s.dev_w.value(),s.dev_h.value()
        if abs(x)<6:x=0
        elif abs(x-dw)<6:x=dw
        if abs(y)<6:y=0
        elif abs(y-dh)<6:y=dh
        return x,y

    def _save_undo(s):
        s.undo.push({"pins":copy.deepcopy(s.pins),"leds":copy.deepcopy(s.leds)});s._uu()
    def _uu(s):
        if hasattr(s,'st_undo'):
            u="U" if s.undo.can_undo() else "-";r="R" if s.undo.can_redo() else "-";s.st_undo.setText(f"[{u}/{r}]")
    def _do_undo(s):
        st=s.undo.undo()
        if st:s.pins=st["pins"];s.leds=st["leds"];s._deselect();s._rl();s.canvas.update();s.st_msg.setText("Undo");s._uu()
    def _do_redo(s):
        st=s.undo.redo()
        if st:s.pins=st["pins"];s.leds=st["leds"];s._deselect();s._rl();s.canvas.update();s.st_msg.setText("Redo");s._uu()

    def _build_ui(s):
        cw=QWidget();s.setCentralWidget(cw);ml=QVBoxLayout(cw);ml.setContentsMargins(0,0,0,0);ml.setSpacing(0)
        hdr=QWidget();hdr.setFixedHeight(40);hdr.setStyleSheet("background:"+T.panel+";border-bottom:1px solid "+T.border)
        hl=QHBoxLayout(hdr);hl.setContentsMargins(14,0,14,0);hl.setSpacing(8)
        logo=QLabel("ASTERON");logo.setFont(QFont(T.MONO,13,QFont.Bold));logo.setStyleSheet("color:"+T.orange+";letter-spacing:3px");hl.addWidget(logo)
        sub=QLabel("DEVICE CREATOR");sub.setFont(QFont(T.MONO,9));sub.setStyleSheet("color:"+T.blue+";letter-spacing:2px");hl.addWidget(sub)
        for c in[T.blue,T.red,T.green,T.orange]:d=QLabel("\u25cf");d.setFont(QFont(T.MONO,8));d.setStyleSheet("color:"+c);hl.addWidget(d)
        hl.addStretch()
        ib=_abtn("Import .adev",T.blue,s._import_adev);ib.setToolTip("Import an existing .adev device file");hl.addWidget(ib)
        eb=_abtn("Export .adev",T.green,s._export);eb.setToolTip("Export device to .adev file (Ctrl+S)");hl.addWidget(eb);ml.addWidget(hdr)
        s.tabs=QTabWidget();ml.addWidget(s.tabs)
        s._build_info();s._build_visual();s._build_emu();s._build_preview();s._build_export()

    def _build_info(s):
        outer=QScrollArea();outer.setWidgetResizable(True);w=QWidget();lay=QVBoxLayout(w);lay.setContentsMargins(28,20,28,20);lay.setSpacing(6)
        lay.addWidget(_lbl("DEVICE IDENTITY",T.orange))
        s.dev_id=make_line("my_device",lay,"ID (unique, no spaces)",mono=True)
        s.dev_name=make_line("My Device",lay,"DISPLAY NAME")
        s.dev_category=make_combo(CATEGORIES,"Other",lay,"CATEGORY")
        lay.addWidget(_lbl("DESCRIPTION",T.textSec))
        s.dev_desc=QPlainTextEdit();s.dev_desc.setMaximumHeight(70);s.dev_desc.setFont(QFont(T.UI,11));lay.addWidget(s.dev_desc)
        lay.addWidget(_sep());lay.addWidget(_lbl("METADATA",T.blue))
        s.dev_author=make_line("",lay,"AUTHOR");s.dev_version=make_line("1.0",lay,"VERSION",mono=True)
        lay.addWidget(_sep());lay.addWidget(_lbl("VISUAL DIMENSIONS",T.green))
        r3=QHBoxLayout();v5=QVBoxLayout();s.dev_w=make_spin(100,10,9999,v5,"WIDTH (px)");r3.addLayout(v5)
        v6=QVBoxLayout();s.dev_h=make_spin(100,10,9999,v6,"HEIGHT (px)");r3.addLayout(v6);lay.addLayout(r3)
        s.dev_label=make_line("My Device",lay,"BODY LABEL")
        cr=QHBoxLayout();cr.addWidget(_lbl("COLOR (fallback)"))
        s.dev_color=QLineEdit("#555");s.dev_color.setFont(QFont(T.MONO,11))
        bc=QPushButton("Pick");bc.clicked.connect(s._pick_color);cr.addWidget(bc);cr.addWidget(s.dev_color);lay.addLayout(cr)
        lay.addStretch();outer.setWidget(w);s.tabs.addTab(outer,"\u25cf Info")
    def _pick_color(s):
        c=QColorDialog.getColor(QColor(s.dev_color.text()),s)
        if c.isValid():s.dev_color.setText(c.name())

    def _build_visual(s):
        w=QWidget();lo=QHBoxLayout(w);lo.setContentsMargins(0,0,0,0);lo.setSpacing(0)
        left=QWidget();ll=QVBoxLayout(left);ll.setContentsMargins(0,0,0,0);ll.setSpacing(0)
        tb1=QWidget();tb1.setFixedHeight(38);tb1.setStyleSheet("background:"+T.panelAlt+";border-bottom:1px solid "+T.border)
        t1=QHBoxLayout(tb1);t1.setContentsMargins(8,0,8,0);t1.setSpacing(4)
        s.vtool_btns={}
        for tid,lb,clr in[("select","Select [1]",T.blue),("pin","Pin [2]",T.green),("led","LED [3]",T.red),("display","Display [4]",T.orange),("move_image","Move Img [5]",T.purple)]:
            b=QPushButton(lb);b.setCheckable(True);b.setChecked(tid=="select");b.setFont(QFont(T.MONO,9,QFont.Bold))
            dm={T.blue:T.blueDim,T.red:T.redDim,T.green:T.greenDim,T.orange:T.orangeDim,T.purple:"#2a1a44"}.get(clr,T.blueDim)
            b.setStyleSheet("QPushButton{background:"+T.surface+";color:"+T.text+";border:1px solid "+T.border+";border-radius:4px;padding:4px 10px}QPushButton:hover{border-color:"+clr+"}QPushButton:checked{background:"+dm+";border-color:"+clr+";color:"+clr+"}")
            b.clicked.connect(lambda _,t=tid:s._set_vtool(t));t1.addWidget(b);s.vtool_btns[tid]=b
        t1.addWidget(_vsep());t1.addStretch()
        s.vis_info=QLabel("100x100 | 0 pins | 0 LEDs");s.vis_info.setFont(QFont(T.MONO,9));s.vis_info.setStyleSheet("color:"+T.orange);t1.addWidget(s.vis_info)
        ll.addWidget(tb1)
        tb2=QWidget();tb2.setFixedHeight(34);tb2.setStyleSheet("background:"+T.panel+";border-bottom:1px solid "+T.border)
        t2=QHBoxLayout(tb2);t2.setContentsMargins(8,0,8,0);t2.setSpacing(5)
        t2.addWidget(_abtn("Upload",T.blue,s._upload_image))
        br=QPushButton("Rm");br.setToolTip("Remove image");br.setStyleSheet("QPushButton{color:"+T.red+";padding:3px 6px}");br.clicked.connect(s._remove_image);t2.addWidget(br)
        t2.addWidget(_vsep())
        for lbt,attr in[("W:","img_w_spin"),("H:","img_h_spin")]:
            lb=QLabel(lbt);lb.setStyleSheet("color:"+T.textMut+";font-size:10px");t2.addWidget(lb)
            sp=QSpinBox();sp.setRange(1,9999);sp.setValue(100);sp.setFixedWidth(55);sp.setFont(QFont(T.MONO,9))
            setattr(s,attr,sp);t2.addWidget(sp)
        s.img_w_spin.valueChanged.connect(lambda v:(setattr(s.canvas,'img_w',v),s.canvas.update()))
        s.img_h_spin.valueChanged.connect(lambda v:(setattr(s.canvas,'img_h',v),s.canvas.update()))
        bf=QPushButton("Fit");bf.setToolTip("Fit to device size");bf.clicked.connect(s._fit_image);t2.addWidget(bf)
        t2.addWidget(_vsep())
        for lbt,attr in[("oX:","img_ox_spin"),("oY:","img_oy_spin")]:
            lb=QLabel(lbt);lb.setStyleSheet("color:"+T.textMut+";font-size:10px");t2.addWidget(lb)
            sp=QSpinBox();sp.setRange(-9999,9999);sp.setValue(0);sp.setFixedWidth(50);sp.setFont(QFont(T.MONO,9))
            setattr(s,attr,sp);t2.addWidget(sp)
        s.img_ox_spin.valueChanged.connect(lambda v:(setattr(s.canvas,'img_ox',v),s.canvas.update()))
        s.img_oy_spin.valueChanged.connect(lambda v:(setattr(s.canvas,'img_oy',v),s.canvas.update()))
        t2.addWidget(_vsep())
        lb=QLabel("Op:");lb.setStyleSheet("color:"+T.textMut+";font-size:10px");t2.addWidget(lb)
        s.opacity_slider=QSlider(Qt.Horizontal);s.opacity_slider.setRange(5,100);s.opacity_slider.setValue(100);s.opacity_slider.setFixedWidth(55)
        s.opacity_slider.valueChanged.connect(lambda v:(setattr(s.canvas,'img_opacity',v/100.0),s.canvas.update()));t2.addWidget(s.opacity_slider)
        t2.addWidget(_vsep())
        s.grid_check=QCheckBox("Grid");s.grid_check.setChecked(True);s.grid_check.toggled.connect(s._on_grid_toggle);t2.addWidget(s.grid_check)
        s.snap_check=QCheckBox("Snap");s.snap_check.setChecked(True);s.snap_check.toggled.connect(lambda v:setattr(s.canvas,'grid_snap',v));t2.addWidget(s.snap_check)
        s.grid_spin=QSpinBox();s.grid_spin.setRange(2,64);s.grid_spin.setValue(8);s.grid_spin.setFixedWidth(45);s.grid_spin.setFont(QFont(T.MONO,9))
        s.grid_spin.valueChanged.connect(lambda v:(setattr(s.canvas,'grid_size',v),s.canvas.update()));t2.addWidget(s.grid_spin)
        t2.addStretch();ll.addWidget(tb2)
        s.canvas=VisualCanvas(s)
        s.canvas.pinPlaced.connect(s._on_pin_placed);s.canvas.ledPlaced.connect(s._on_led_placed)
        s.canvas.displayDrawn.connect(s._on_disp_drawn);s.canvas.itemClicked.connect(s._on_item_clicked)
        s.canvas.itemMoved.connect(s._on_item_moved);s.canvas.mouseAt.connect(lambda x,y:s.st_coord.setText(f"({x}, {y})"))
        ll.addWidget(s.canvas);lo.addWidget(left,1)
        right=QWidget();right.setFixedWidth(300);right.setStyleSheet("background:"+T.panel+";border-left:1px solid "+T.border)
        rl=QVBoxLayout(right);rl.setContentsMargins(0,0,0,0)
        s.prop_stack=QStackedWidget();rl.addWidget(s.prop_stack)
        s._build_overview();s._build_pin_ed();s._build_led_ed()
        s.prop_stack.setCurrentIndex(0);lo.addWidget(right);s.tabs.addTab(w,"\u25cf Visual")

    def _on_grid_toggle(s,on):
        s.canvas.grid_on=on
        if not on:s.canvas.grid_snap=False;s.snap_check.setChecked(False)
        s.canvas.update()
    def _toggle_grid(s):s.grid_check.setChecked(not s.grid_check.isChecked())
    def _sync_img_offset(s):
        s.img_ox_spin.blockSignals(True);s.img_oy_spin.blockSignals(True)
        s.img_ox_spin.setValue(s.canvas.img_ox);s.img_oy_spin.setValue(s.canvas.img_oy)
        s.img_ox_spin.blockSignals(False);s.img_oy_spin.blockSignals(False)

    def _build_overview(s):
        pg=QScrollArea();pg.setWidgetResizable(True);inner=QWidget();lay=QVBoxLayout(inner);lay.setContentsMargins(12,10,12,10);lay.setSpacing(4)
        lay.addWidget(_lbl("PINS",T.green))
        s.pin_list=QListWidget();s.pin_list.setMaximumHeight(160);s.pin_list.itemClicked.connect(lambda:s._on_item_clicked("pin",s.pin_list.currentRow()));lay.addWidget(s.pin_list)
        al=QHBoxLayout();al.setSpacing(4)
        for sd,lb in[("left","L"),("right","R"),("top","T"),("bottom","B")]:
            b=QPushButton(lb);b.setFixedWidth(32);b.setToolTip(f"Auto-layout on {sd}");b.clicked.connect(lambda _,ss=sd:s._auto_layout(ss));al.addWidget(b)
        al.addWidget(_lbl("layout"));al.addStretch();lay.addLayout(al)
        lay.addWidget(_sep());lay.addWidget(_lbl("LED INDICATORS",T.red))
        s.led_list=QListWidget();s.led_list.setMaximumHeight(100);s.led_list.itemClicked.connect(lambda:s._on_item_clicked("led",s.led_list.currentRow()));lay.addWidget(s.led_list)
        lay.addWidget(_sep());lay.addWidget(_lbl("DISPLAY",T.orange))
        s.has_display=QCheckBox("Has display");s.has_display.toggled.connect(lambda:s.canvas.update());lay.addWidget(s.has_display)
        dg=QWidget();dl=QVBoxLayout(dg);dl.setContentsMargins(0,4,0,0);dl.setSpacing(4)
        s.disp_type=make_line("oled_ssd1306",dl,"TYPE",mono=True)
        r1=QHBoxLayout();v1=QVBoxLayout();s.disp_px_w=make_spin(128,1,4096,v1,"PX W");r1.addLayout(v1)
        v2=QVBoxLayout();s.disp_px_h=make_spin(64,1,4096,v2,"PX H");r1.addLayout(v2);dl.addLayout(r1)
        r2=QHBoxLayout();v3=QVBoxLayout();s.disp_color=make_line("#00aaff",v3,"PX CLR",mono=True);r2.addLayout(v3)
        v4=QVBoxLayout();s.disp_bg=make_line("#000510",v4,"BG CLR",mono=True);r2.addLayout(v4);dl.addLayout(r2)
        r3=QHBoxLayout();v5=QVBoxLayout();s.disp_iface=make_combo(["i2c","spi","parallel"],"i2c",v5,"IFACE");r3.addLayout(v5)
        v6=QVBoxLayout();s.disp_addr=make_line("0x3C",v6,"ADDR",mono=True);r3.addLayout(v6);dl.addLayout(r3)
        lay.addWidget(dg);lay.addStretch()
        sh=QLabel("1-5=tools  R=rotate pin  G=grid  Del=delete\nSpace+drag=pan  Scroll=zoom  Home=reset\nRclick=menu  Ctrl+Z=undo  Ctrl+Shift+Z=redo\nCtrl+D=duplicate  Ctrl+S=export")
        sh.setFont(QFont(T.MONO,8));sh.setStyleSheet("color:"+T.textMut+";padding:6px;border-top:1px solid "+T.border);sh.setWordWrap(True);lay.addWidget(sh)
        pg.setWidget(inner);s.prop_stack.addWidget(pg)

    def _build_pin_ed(s):
        pg=QScrollArea();pg.setWidgetResizable(True);inner=QWidget();lay=QVBoxLayout(inner);lay.setContentsMargins(12,10,12,10);lay.setSpacing(4)
        hdr=QHBoxLayout();t=QLabel("Pin Properties");t.setFont(QFont(T.UI,14,QFont.Bold));t.setStyleSheet("color:"+T.green);hdr.addWidget(t)
        hdr.addWidget(_abtn("Back",T.blue,s._deselect));lay.addLayout(hdr)
        s.pe_id=make_line("",lay,"ID (unique)",mono=True);s.pe_label=make_line("",lay,"LABEL",mono=True)
        r=QHBoxLayout();v1=QVBoxLayout();s.pe_x=make_spin(0,-9999,9999,v1,"X");r.addLayout(v1)
        v2=QVBoxLayout();s.pe_y=make_spin(0,-9999,9999,v2,"Y");r.addLayout(v2);lay.addLayout(r)
        s.pe_type=make_combo(PIN_TYPES,"digital",lay,"TYPE");s.pe_dir=make_combo(PIN_DIRS,"io",lay,"DIRECTION")
        s.pe_side=make_combo(PIN_SIDES,"left",lay,"SIDE")
        lay.addWidget(_sep());lay.addWidget(_lbl("APPEARANCE",T.orange))
        r2=QHBoxLayout();v3=QVBoxLayout();s.pe_shape=make_combo(PIN_SHAPES,"circle",v3,"SHAPE");r2.addLayout(v3)
        v4=QVBoxLayout();s.pe_size=make_spin(4,2,20,v4,"SIZE (radius)");r2.addLayout(v4);lay.addLayout(r2)
        lay.addWidget(_lbl("ROTATION",T.orange))
        rot_row=QHBoxLayout();s.pe_rotation=QComboBox();s.pe_rotation.addItems(["0","90","180","270"]);s.pe_rotation.setFont(QFont(T.MONO,11));rot_row.addWidget(s.pe_rotation)
        for deg,lb in[(0,"0\u00b0"),(90,"90\u00b0"),(180,"180\u00b0"),(270,"270\u00b0")]:
            b=QPushButton(lb);b.setFixedWidth(36)
            b.setStyleSheet("QPushButton{padding:3px;font-size:10px;background:"+T.surface+";color:"+T.orange+";border:1px solid "+T.border+";border-radius:3px}QPushButton:hover{background:"+T.orangeDim+";border-color:"+T.orange+"}")
            b.clicked.connect(lambda _,d=deg:s._set_cur_pin_rotation(d));rot_row.addWidget(b)
        lay.addLayout(rot_row)
        s.pe_notes=make_line("",lay,"NOTES")
        for w,f in[(s.pe_id,"id"),(s.pe_label,"label"),(s.pe_notes,"notes")]:w.textChanged.connect(lambda v,ff=f:s._up(ff,v))
        for w,f in[(s.pe_x,"x"),(s.pe_y,"y"),(s.pe_size,"size")]:w.valueChanged.connect(lambda v,ff=f:s._up(ff,v))
        for w,f in[(s.pe_type,"type"),(s.pe_dir,"direction"),(s.pe_side,"side"),(s.pe_shape,"shape")]:w.currentTextChanged.connect(lambda v,ff=f:s._up(ff,v))
        s.pe_rotation.currentTextChanged.connect(lambda v:s._up("rotation",int(v)) if v.isdigit() else None)
        lay.addSpacing(8);lay.addWidget(_sep())
        lay.addWidget(_abtn("Rotate +90\u00b0 (R)",T.orange,lambda:s._rotate_selected_pin()))
        lay.addWidget(_abtn("Flip Side",T.blue,lambda:s._flip_pin_side(s.sel_idx)))
        lay.addWidget(_abtn("Duplicate",T.orange,lambda:s._dup_item("pin",s.sel_idx)))
        lay.addWidget(_abtn("Delete",T.red,s._delete_selected));lay.addStretch()
        pg.setWidget(inner);s.prop_stack.addWidget(pg)

    def _build_led_ed(s):
        pg=QScrollArea();pg.setWidgetResizable(True);inner=QWidget();lay=QVBoxLayout(inner);lay.setContentsMargins(12,10,12,10);lay.setSpacing(4)
        hdr=QHBoxLayout();t=QLabel("LED Indicator");t.setFont(QFont(T.UI,14,QFont.Bold));t.setStyleSheet("color:"+T.red);hdr.addWidget(t)
        hdr.addWidget(_abtn("Back",T.blue,s._deselect));lay.addLayout(hdr)
        s.le_label=make_line("",lay,"LABEL",mono=True)
        r=QHBoxLayout();v1=QVBoxLayout();s.le_x=make_spin(0,-9999,9999,v1,"X");r.addLayout(v1)
        v2=QVBoxLayout();s.le_y=make_spin(0,-9999,9999,v2,"Y");r.addLayout(v2);lay.addLayout(r)
        s.le_radius=make_spin(8,1,100,lay,"RADIUS")
        lay.addWidget(_lbl("COLOR",T.red));cr=QHBoxLayout()
        s.le_color_btn=QPushButton("  ");s.le_color_btn.setFixedSize(30,30)
        s.le_color_btn.setStyleSheet("background:#ff3344;border:1px solid "+T.border+";border-radius:4px")
        s.le_color_btn.clicked.connect(s._pick_led_color);cr.addWidget(s.le_color_btn)
        s.le_color=QLineEdit("#ff3344");s.le_color.setFont(QFont(T.MONO,11))
        s.le_color.textChanged.connect(lambda t:s.le_color_btn.setStyleSheet("background:"+t+";border:1px solid "+T.border+";border-radius:4px") if QColor(t).isValid() else None)
        cr.addWidget(s.le_color);lay.addLayout(cr)
        s.le_state_var=make_line("led_on",lay,"STATE VAR",mono=True);s.le_on_value=make_line("true",lay,"ON VALUE",mono=True)
        for w,f in[(s.le_label,"label"),(s.le_color,"color"),(s.le_state_var,"state_var"),(s.le_on_value,"on_value_str")]:w.textChanged.connect(lambda v,ff=f:s._ul(ff,v))
        for w,f in[(s.le_x,"x"),(s.le_y,"y"),(s.le_radius,"radius")]:w.valueChanged.connect(lambda v,ff=f:s._ul(ff,v))
        lay.addSpacing(8);lay.addWidget(_sep())
        lay.addWidget(_abtn("Duplicate",T.orange,lambda:s._dup_item("led",s.sel_idx)))
        lay.addWidget(_abtn("Delete",T.red,s._delete_selected));lay.addStretch()
        pg.setWidget(inner);s.prop_stack.addWidget(pg)
    def _pick_led_color(s):
        c=QColorDialog.getColor(QColor(s.le_color.text()),s)
        if c.isValid():s.le_color.setText(c.name())

    def _build_emu(s):
        w=QWidget();lo=QHBoxLayout(w);lo.setContentsMargins(0,0,0,0);lo.setSpacing(0)
        left=QWidget();ll=QVBoxLayout(left);ll.setContentsMargins(0,0,0,0);ll.setSpacing(0)
        tbw=QWidget();tbw.setFixedHeight(34);tbw.setStyleSheet("background:"+T.panelAlt+";border-bottom:1px solid "+T.border)
        tbl=QHBoxLayout(tbw);tbl.setContentsMargins(12,0,12,0);tbl.addWidget(_lbl("emulation.json",T.blue));tbl.addStretch()
        s.emu_status=QLabel("Valid JSON");s.emu_status.setFont(QFont(T.MONO,10));s.emu_status.setStyleSheet("color:"+T.green);tbl.addWidget(s.emu_status)
        tbl.addWidget(_abtn("Format",T.blue,s._format_emu));ll.addWidget(tbw)
        s.emu_editor=QPlainTextEdit();s.emu_editor.setPlainText(DEFAULT_EMU);s.emu_editor.setFont(QFont(T.MONO,12));s.emu_editor.textChanged.connect(s._validate_emu)
        ll.addWidget(s.emu_editor);lo.addWidget(left,1)
        right=QWidget();right.setFixedWidth(230);right.setStyleSheet("background:"+T.panel+";border-left:1px solid "+T.border)
        rl=QVBoxLayout(right);rl.setContentsMargins(10,10,10,10);rl.setSpacing(6)
        triggers=["pin_high","pin_low","pin_pwm","analog_read","user_press","user_release","tone","i2c_command","display_print","circuit_update"]
        actions=["set_state","compute","return_value","visual_update","render_text","set_pixel","clear_framebuffer"]
        for title,items,clr in[("TRIGGERS",triggers,T.orange),("ACTIONS",actions,T.green)]:
            rl.addWidget(_lbl(title,clr));lw=QListWidget();lw.setMaximumHeight(min(120,len(items)*22));lw.setFont(QFont(T.MONO,10))
            for i in items:lw.addItem(i)
            rl.addWidget(lw)
        rl.addWidget(_lbl("YOUR PINS",T.blue));s.emu_pin_list=QListWidget();s.emu_pin_list.setMaximumHeight(100);s.emu_pin_list.setFont(QFont(T.MONO,10));rl.addWidget(s.emu_pin_list);rl.addStretch()
        lo.addWidget(right);s.tabs.addTab(w,"\u25cf Emulation")
    def _validate_emu(s):
        try:json.loads(s.emu_editor.toPlainText());s.emu_status.setText("Valid JSON");s.emu_status.setStyleSheet("color:"+T.green);return True
        except json.JSONDecodeError as e:s.emu_status.setText("Error: "+str(e)[:35]);s.emu_status.setStyleSheet("color:"+T.red);return False
    def _format_emu(s):
        try:s.emu_editor.setPlainText(json.dumps(json.loads(s.emu_editor.toPlainText()),indent=2))
        except Exception:pass

    def _build_preview(s):
        w=QWidget();lo=QVBoxLayout(w);lo.setContentsMargins(0,0,0,0);lo.setSpacing(0)
        tbw=QWidget();tbw.setFixedHeight(38);tbw.setStyleSheet("background:"+T.panelAlt+";border-bottom:1px solid "+T.border)
        tb=QHBoxLayout(tbw);tb.setContentsMargins(12,0,12,0);tb.setSpacing(10);tb.addWidget(_lbl("Live Preview",T.blue))
        s.btn_test=_abtn("Run Test",T.green,s._toggle_test);tb.addWidget(s.btn_test)
        s.test_lbl=QLabel("");s.test_lbl.setFont(QFont(T.MONO,10));s.test_lbl.setStyleSheet("color:"+T.green);tb.addWidget(s.test_lbl);tb.addStretch();lo.addWidget(tbw)
        s.preview_canvas=VisualCanvas(s);s.preview_canvas.tool="select";s.preview_canvas.zoom=3.0;lo.addWidget(s.preview_canvas,1)
        sw=QWidget();sw.setFixedHeight(60);sw.setStyleSheet("background:"+T.panel+";border-top:1px solid "+T.border)
        sl=QVBoxLayout(sw);sl.setContentsMargins(12,6,12,6);sl.addWidget(_lbl("STATE",T.green))
        s.state_display=QLabel("No state");s.state_display.setFont(QFont(T.MONO,10));s.state_display.setStyleSheet("color:"+T.textSec);s.state_display.setWordWrap(True);sl.addWidget(s.state_display)
        lo.addWidget(sw);s.tabs.addTab(w,"\u25cf Preview")
    def _toggle_test(s):
        if s.test_running:s.test_running=False;s.test_state={};s.test_timer.stop();s.btn_test.setText("Run Test");s.test_lbl.setText("");s.state_display.setText("Stopped")
        else:s.test_running=True;s.test_tick=0;s.test_timer.start();s.btn_test.setText("Stop")
        s.canvas.update();s.preview_canvas.update()
    def _test_tick(s):
        s.test_tick+=1
        try:
            emu=json.loads(s.emu_editor.toPlainText());sv=dict(emu.get("state_vars",{}))
            for r in emu.get("rules",[]):
                if r.get("action")=="set_state" and r.get("target") and r.get("trigger")=="pin_high":
                    v=r.get("value")
                    if isinstance(v,bool):sv[r["target"]]=v if s.test_tick%2==0 else(not v)
                    else:sv[r["target"]]=v if s.test_tick%2==0 else 0
            s.test_state=sv;s.state_display.setText("  |  ".join(f"{k}: {v}" for k,v in sv.items()) or "Empty")
        except Exception:pass
        s.test_lbl.setText(f"tick {s.test_tick}");s.canvas.update();s.preview_canvas.update()

    def _build_export(s):
        w=QWidget();lo=QHBoxLayout(w);lo.setContentsMargins(0,0,0,0)
        left=QWidget();ll=QVBoxLayout(left);ll.setContentsMargins(28,24,28,24);ll.setSpacing(10)
        h=QLabel("Export Device File");h.setFont(QFont(T.UI,18,QFont.Bold));h.setStyleSheet("color:"+T.green);ll.addWidget(h)
        s.export_summary=QTextEdit();s.export_summary.setReadOnly(True);s.export_summary.setMaximumHeight(240);s.export_summary.setFont(QFont(T.MONO,11))
        s.export_summary.setStyleSheet("background:"+T.bg+";border:1px solid "+T.border+";border-radius:4px;padding:12px");ll.addWidget(s.export_summary)
        s.export_warn=QLabel("");s.export_warn.setFont(QFont(T.MONO,10));s.export_warn.setStyleSheet("color:"+T.orange);s.export_warn.setWordWrap(True);ll.addWidget(s.export_warn)
        s.export_err=QLabel("");s.export_err.setFont(QFont(T.MONO,10));s.export_err.setStyleSheet("color:"+T.red);ll.addWidget(s.export_err)
        btn=QPushButton("Save .adev");btn.setStyleSheet("QPushButton{background:"+T.green+";color:#000;border:none;border-radius:4px;padding:14px;font-size:14px;font-weight:bold}QPushButton:hover{background:#55ee77}")
        btn.clicked.connect(s._export);ll.addWidget(btn);ll.addStretch();lo.addWidget(left,1)
        right=QWidget();rl=QVBoxLayout(right);rl.setContentsMargins(0,0,0,0);rl.setSpacing(0);rl.addWidget(_lbl("  JSON Preview"))
        s.export_preview=QPlainTextEdit();s.export_preview.setReadOnly(True);s.export_preview.setFont(QFont(T.MONO,11));rl.addWidget(s.export_preview)
        lo.addWidget(right,1);s.tabs.addTab(w,"\u25cf Export");s.tabs.currentChanged.connect(s._on_tab)

    def _on_tab(s,idx):
        nm=s.tabs.tabText(idx)
        if "Export" in nm:s._update_export()
        elif "Emulation" in nm:
            s.emu_pin_list.clear()
            for p in s.pins:s.emu_pin_list.addItem(f'{p["id"]} ({p["type"]})')
        elif "Preview" in nm:
            for attr in['image','image_path','img_w','img_h','img_ox','img_oy','img_opacity']:
                setattr(s.preview_canvas,attr,getattr(s.canvas,attr))
            s.preview_canvas.center_view()
    def _update_export(s):
        ad=s._build_adev()
        if ad:
            warns=[]
            if not s.pins:warns.append("No pins defined")
            if not s.dev_id.text().strip():warns.append("Device ID is empty")
            elif not _validate_device_id(s.dev_id.text().strip()):warns.append("Invalid device ID (use letters/numbers/underscore)")
            ids=[p["id"] for p in s.pins]
            if len(ids)!=len(set(ids)):warns.append("Duplicate pin IDs")
            s.export_warn.setText("\u26a0 "+" | ".join(warns) if warns else "")
            pv=json.loads(json.dumps(ad));img=pv.get("visual",{}).get("image_svg")
            if img and len(img)>200:pv["visual"]["image_svg"]="(base64 truncated)"
            s.export_preview.setPlainText(json.dumps(pv,indent=2))
            np=len(ad.get("pins",[]));nl=len(ad["visual"].get("led_indicators",[]))
            rot_count=sum(1 for p in s.pins if p.get("rotation",0)!=0)
            s.export_summary.setPlainText(f'Name: {ad["device"]["name"]}\nID: {ad["device"]["id"]}\nCategory: {ad["device"]["category"]}\nSize: {ad["visual"]["width"]}x{ad["visual"]["height"]}\nImage: {"Yes ("+str(s.canvas.img_w)+"x"+str(s.canvas.img_h)+")" if s.image_b64 else "No"}\nImage Offset: ({s.canvas.img_ox}, {s.canvas.img_oy})\nPins: {np}\nLEDs: {nl}\nDisplay: {"Yes" if "display" in ad else "No"}\nRotated pins: {rot_count}')
            s.export_err.setText("")
        else:s.export_err.setText("Fix emulation JSON first.")

    # ═══════════════════ ACTIONS ═══════════════════
    def _set_vtool(s,t):s.canvas.tool=t;s._sync_tools()
    def _sync_tools(s):
        for k,b in s.vtool_btns.items():b.setChecked(k==s.canvas.tool)
    def _fit_image(s):
        if s.canvas.image and not s.canvas.image.isNull():
            s.img_w_spin.setValue(s.dev_w.value());s.img_h_spin.setValue(s.dev_h.value())
            s.img_ox_spin.setValue(0);s.img_oy_spin.setValue(0)
    def _upload_image(s):
        f,_=QFileDialog.getOpenFileName(s,"Upload","","Images (*.png *.jpg *.jpeg *.bmp);;All (*)")
        if not f:return
        img=QImage(f)
        if img.isNull():QMessageBox.warning(s,"Error","Failed");return
        s.canvas.set_image(img,f);s.dev_w.setValue(img.width());s.dev_h.setValue(img.height())
        s.img_w_spin.setValue(img.width());s.img_h_spin.setValue(img.height())
        s.img_ox_spin.setValue(0);s.img_oy_spin.setValue(0)
        with open(f,"rb") as fh:s.image_b64=base64.b64encode(fh.read()).decode("ascii")
        s.preview_canvas.image=img;s.preview_canvas.image_path=f
        s.st_msg.setText(f"Image: {Path(f).name} ({img.width()}x{img.height()})");s._ri();s.canvas.center_view();s._mark_unsaved()
    def _remove_image(s):s.canvas.clear_image();s.preview_canvas.image=None;s.image_b64=None;s.st_msg.setText("Image removed");s._mark_unsaved()

    def _next_pin_num(s):
        existing=set()
        for p in s.pins:
            lb=p.get("label","")
            if lb.startswith("P") and lb[1:].isdigit():existing.add(int(lb[1:]))
        n=0
        while n in existing:n+=1
        return n
    def _next_led_num(s):
        existing=set()
        for l in s.leds:
            lb=l.get("label","")
            if lb.startswith("LED") and lb[3:].isdigit():existing.add(int(lb[3:]))
        n=0
        while n in existing:n+=1
        return n
    def _on_pin_placed(s,x,y):
        x,y=s._snap_to_edge(x,y);s._check_pin_bounds(x,y)
        n=s._next_pin_num()
        s.pins.append({"id":f"pin_{n}","label":f"P{n}","x":x,"y":y,"side":"left","type":"digital","direction":"io","notes":"","shape":"circle","size":4,"rotation":0})
        s._save_undo();s._rl();s._on_item_clicked("pin",len(s.pins)-1);s.canvas.update();s._mark_unsaved()
    def _on_led_placed(s,x,y):
        n=s._next_led_num()
        s.leds.append({"label":f"LED{n}","x":x,"y":y,"radius":8,"color":"#ff3344","state_var":"led_on","on_value":True})
        s._save_undo();s._rl();s._on_item_clicked("led",len(s.leds)-1);s.canvas.update();s._mark_unsaved()
    def _on_disp_drawn(s,x,y,w,h):s.disp_region={"x":x,"y":y,"w":w,"h":h};s.has_display.setChecked(True);s.canvas.update()
    def _on_item_moved(s,t,i,x,y):
        s._save_undo();s._mark_unsaved()
        if t=="pin" and s.sel_type=="pin" and s.sel_idx==i:
            s.pe_x.blockSignals(True);s.pe_y.blockSignals(True);s.pe_x.setValue(x);s.pe_y.setValue(y);s.pe_x.blockSignals(False);s.pe_y.blockSignals(False)
        elif t=="led" and s.sel_type=="led" and s.sel_idx==i:
            s.le_x.blockSignals(True);s.le_y.blockSignals(True);s.le_x.setValue(x);s.le_y.setValue(y);s.le_x.blockSignals(False);s.le_y.blockSignals(False)
        s._rl()
    def _on_item_clicked(s,t,i):
        s.sel_type=t;s.sel_idx=i
        if t=="pin" and 0<=i<len(s.pins):
            p=s.pins[i];ws=[s.pe_id,s.pe_label,s.pe_notes,s.pe_x,s.pe_y,s.pe_type,s.pe_dir,s.pe_side,s.pe_shape,s.pe_size,s.pe_rotation]
            for w in ws:w.blockSignals(True)
            s.pe_id.setText(p["id"]);s.pe_label.setText(p["label"]);s.pe_x.setValue(p["x"]);s.pe_y.setValue(p["y"])
            s.pe_type.setCurrentText(p["type"]);s.pe_dir.setCurrentText(p["direction"]);s.pe_side.setCurrentText(p["side"])
            s.pe_shape.setCurrentText(p.get("shape","circle"));s.pe_size.setValue(p.get("size",4))
            s.pe_rotation.setCurrentText(str(p.get("rotation",0)))
            for w in ws:w.blockSignals(False)
            s.prop_stack.setCurrentIndex(1)
        elif t=="led" and 0<=i<len(s.leds):
            l=s.leds[i];ws=[s.le_label,s.le_x,s.le_y,s.le_radius,s.le_color,s.le_state_var,s.le_on_value]
            for w in ws:w.blockSignals(True)
            s.le_label.setText(l["label"]);s.le_x.setValue(l["x"]);s.le_y.setValue(l["y"]);s.le_radius.setValue(l.get("radius",8))
            s.le_color.setText(l.get("color","#ff3344"));s.le_state_var.setText(l.get("state_var",""))
            ov=l.get("on_value",True);s.le_on_value.setText(str(ov).lower() if isinstance(ov,bool) else str(ov))
            for w in ws:w.blockSignals(False)
            s.prop_stack.setCurrentIndex(2)
        else:s._deselect()
        s.canvas.update()
        if hasattr(s,'preview_canvas'):s.preview_canvas.update()
    def _deselect(s):s.sel_type="none";s.sel_idx=-1;s.prop_stack.setCurrentIndex(0);s.pin_list.clearSelection();s.led_list.clearSelection();s.canvas.update()
    def _up(s,f,v):
        if s.sel_type=="pin" and 0<=s.sel_idx<len(s.pins):s.pins[s.sel_idx][f]=v;s._rl();s.canvas.update();s._mark_unsaved()
    def _ul(s,f,v):
        if s.sel_type=="led" and 0<=s.sel_idx<len(s.leds):
            if f=="on_value_str":
                if v.lower()=="true":v=True
                elif v.lower()=="false":v=False
                else:
                    try:v=float(v) if "." in v else int(v)
                    except ValueError:pass
                s.leds[s.sel_idx]["on_value"]=v
            else:s.leds[s.sel_idx][f]=v
            s._rl();s.canvas.update();s._mark_unsaved()
    def _rotate_selected_pin(s):
        if s.sel_type=="pin" and 0<=s.sel_idx<len(s.pins):
            cur=s.pins[s.sel_idx].get("rotation",0);new=(cur+90)%360;s.pins[s.sel_idx]["rotation"]=new
            s.pe_rotation.blockSignals(True);s.pe_rotation.setCurrentText(str(new));s.pe_rotation.blockSignals(False)
            s._save_undo();s._rl();s.canvas.update();s.st_msg.setText(f"Pin rotated to {new}\u00b0");s._mark_unsaved()
    def _set_cur_pin_rotation(s,deg):
        if s.sel_type=="pin" and 0<=s.sel_idx<len(s.pins):
            s.pins[s.sel_idx]["rotation"]=deg
            s.pe_rotation.blockSignals(True);s.pe_rotation.setCurrentText(str(deg));s.pe_rotation.blockSignals(False)
            s._save_undo();s._rl();s.canvas.update();s._mark_unsaved()
    def _set_pin_rotation(s,i,deg):
        if 0<=i<len(s.pins):
            s.pins[i]["rotation"]=deg
            if s.sel_type=="pin" and s.sel_idx==i:
                s.pe_rotation.blockSignals(True);s.pe_rotation.setCurrentText(str(deg));s.pe_rotation.blockSignals(False)
            s._save_undo();s._rl();s.canvas.update();s._mark_unsaved()
    def _flip_pin_side(s,i):
        if 0<=i<len(s.pins):
            order=["left","right","top","bottom"];cur=s.pins[i].get("side","left")
            nxt=order[(order.index(cur)+1)%4] if cur in order else "left";s.pins[i]["side"]=nxt
            if s.sel_type=="pin" and s.sel_idx==i:
                s.pe_side.blockSignals(True);s.pe_side.setCurrentText(nxt);s.pe_side.blockSignals(False)
            s._save_undo();s._rl();s.canvas.update();s.st_msg.setText(f"Pin side \u2192 {nxt}");s._mark_unsaved()
    def _delete_selected(s):s._del_item(s.sel_type,s.sel_idx)
    def _del_item(s,t,i):
        if t=="pin" and 0<=i<len(s.pins):s.pins.pop(i)
        elif t=="led" and 0<=i<len(s.leds):s.leds.pop(i)
        else:return
        s._save_undo();s._deselect();s._rl();s.canvas.update();s._mark_unsaved()
    def _dup_item(s,t,i):
        if t=="pin" and 0<=i<len(s.pins):
            n=copy.deepcopy(s.pins[i]);n["x"]+=16;n["y"]+=16;nn=s._next_pin_num()
            n["id"]=f"pin_{nn}";n["label"]=f"P{nn}";s.pins.append(n);s._save_undo();s._rl();s._on_item_clicked("pin",len(s.pins)-1)
        elif t=="led" and 0<=i<len(s.leds):
            n=copy.deepcopy(s.leds[i]);n["x"]+=16;n["y"]+=16;nn=s._next_led_num();n["label"]=f"LED{nn}"
            s.leds.append(n);s._save_undo();s._rl();s._on_item_clicked("led",len(s.leds)-1)
        s.canvas.update();s._mark_unsaved()
    def _auto_layout(s,sd):
        if not s.pins:return
        dw,dh=s.dev_w.value(),s.dev_h.value();n=len(s.pins)
        for i,p in enumerate(s.pins):
            p["side"]=sd
            if sd=="left":p["x"]=0;p["y"]=int(dh*(i+1)/(n+1))
            elif sd=="right":p["x"]=dw;p["y"]=int(dh*(i+1)/(n+1))
            elif sd=="top":p["x"]=int(dw*(i+1)/(n+1));p["y"]=0
            elif sd=="bottom":p["x"]=int(dw*(i+1)/(n+1));p["y"]=dh
        s._save_undo();s._rl();s.canvas.update();s._mark_unsaved()
    def _rl(s):
        s.pin_list.clear()
        for p in s.pins:
            sh=p.get("shape","circle")[:3];rot=p.get("rotation",0);rot_s=f" {rot}\u00b0" if rot else ""
            sd=p.get("side","?")[0].upper()
            s.pin_list.addItem(f'{p["label"]:6s} {sh} r{p.get("size",4)}  {p["type"]:8s}  {sd}{rot_s}  @{p["x"]},{p["y"]}')
        s.led_list.clear()
        for l in s.leds:s.led_list.addItem(f'{l["label"]} r{l.get("radius",8)} -> {l.get("state_var","?")}')
        s._ri()
    def _ri(s):
        if hasattr(s,"vis_info"):s.vis_info.setText(f"{s.dev_w.value()}x{s.dev_h.value()} | {len(s.pins)} pins | {len(s.leds)} LEDs")

    def _build_adev(s):
        if not s._validate_emu():return None
        try:emu=json.loads(s.emu_editor.toPlainText())
        except Exception:return None
        vis_w=s.dev_w.value();vis_h=s.dev_h.value()
        img_dw=s.canvas.img_w if s.canvas.img_w>0 else vis_w
        img_dh=s.canvas.img_h if s.canvas.img_h>0 else vis_h
        ad={"format_version":"1.0",
            "device":{"id":s.dev_id.text(),"name":s.dev_name.text(),"category":s.dev_category.currentText(),
                "description":s.dev_desc.toPlainText(),"author":s.dev_author.text(),"version":s.dev_version.text()},
            "visual":{"width":vis_w,"height":vis_h,"label":s.dev_label.text(),"color":s.dev_color.text(),
                "image_display_width":img_dw,"image_display_height":img_dh,
                "image_offset_x":s.canvas.img_ox,"image_offset_y":s.canvas.img_oy},
            "pins":[],"emulation":emu}
        for p in s.pins:
            ad["pins"].append({"id":p["id"],"label":p.get("label",""),"x":p["x"],"y":p["y"],
                "side":p.get("side","left"),"type":p.get("type","digital"),"direction":p.get("direction","io"),
                "notes":p.get("notes",""),"shape":p.get("shape","circle"),"size":p.get("size",4),
                "rotation":p.get("rotation",0)})
        if s.image_b64:
            ext=Path(s.canvas.image_path or "x.png").suffix.lower();mime={".png":"image/png",".jpg":"image/jpeg",".jpeg":"image/jpeg"}.get(ext,"image/png")
            ad["visual"]["image_svg"]=f"<svg xmlns='http://www.w3.org/2000/svg' width='{img_dw}' height='{img_dh}'><image href='data:{mime};base64,{s.image_b64}' width='{img_dw}' height='{img_dh}'/></svg>"
        if s.leds:ad["visual"]["led_indicators"]=[{"label":l["label"],"x":l["x"],"y":l["y"],"radius":l.get("radius",8),"color":l.get("color","#ff3344"),"state_var":l.get("state_var",""),"on_value":l.get("on_value",True)} for l in s.leds]
        if s.has_display.isChecked():ad["display"]={"type":s.disp_type.text(),"width_px":s.disp_px_w.value(),"height_px":s.disp_px_h.value(),"pixel_color":s.disp_color.text(),"background_color":s.disp_bg.text(),"region":dict(s.disp_region),"interface":s.disp_iface.currentText(),"address":s.disp_addr.text()}
        return ad
    def _export(s):
        ad=s._build_adev()
        if not ad:QMessageBox.warning(s,"Error","Fix JSON first.");return
        dev_id=s.dev_id.text().strip()
        if not _validate_device_id(dev_id):
            QMessageBox.warning(s,"Invalid ID","Device ID must start with a letter and contain only letters, numbers, and underscores.\nExample: my_led_5mm");return
        nm=dev_id or "device";path,_=QFileDialog.getSaveFileName(s,"Save",f"{nm}.adev","Device Files (*.adev);;JSON (*.json);;All (*)")
        if not path:return
        with open(path,"w",encoding="utf-8") as f:json.dump(ad,f,indent=2)
        s._last_export_path=path;s._unsaved=False;s._update_title();s._add_recent(path)
        s.st_msg.setText(f"Exported: {Path(path).name}");QMessageBox.information(s,"Done",f"Saved:\n{path}")
    def _import_adev(s):
        f,_=QFileDialog.getOpenFileName(s,"Import","","Device Files (*.adev *.json);;All (*)")
        if not f:return
        try:
            with open(f,"r",encoding="utf-8") as fh:data=json.load(fh)
        except Exception as e:QMessageBox.warning(s,"Error",str(e));return
        s._apply_import(data);s._last_export_path=f;s._unsaved=False;s._update_title();s._add_recent(f)
        s.st_msg.setText(f"Imported: {Path(f).name}")
    def _apply_import(s,data):
        dev=data.get("device",{});vis=data.get("visual",{})
        s.dev_id.setText(dev.get("id",""));s.dev_name.setText(dev.get("name",""))
        ci=s.dev_category.findText(dev.get("category","Other"))
        if ci>=0:s.dev_category.setCurrentIndex(ci)
        s.dev_desc.setPlainText(dev.get("description",""));s.dev_author.setText(dev.get("author",""));s.dev_version.setText(dev.get("version","1.0"))
        s.dev_w.setValue(vis.get("width",100));s.dev_h.setValue(vis.get("height",100));s.dev_label.setText(vis.get("label",""));s.dev_color.setText(vis.get("color","#555"))
        s.pins=list(data.get("pins",[]))
        for p in s.pins:p.setdefault("shape","circle");p.setdefault("size",4);p.setdefault("rotation",0)
        s.leds=list(vis.get("led_indicators",[]))
        if vis.get("image_display_width"):s.img_w_spin.setValue(vis["image_display_width"])
        if vis.get("image_display_height"):s.img_h_spin.setValue(vis["image_display_height"])
        s.img_ox_spin.setValue(vis.get("image_offset_x",0));s.img_oy_spin.setValue(vis.get("image_offset_y",0))
        if data.get("emulation"):s.emu_editor.setPlainText(json.dumps(data["emulation"],indent=2))
        if data.get("display"):
            s.has_display.setChecked(True);d=data["display"];s.disp_type.setText(d.get("type",""))
            s.disp_px_w.setValue(d.get("width_px",128));s.disp_px_h.setValue(d.get("height_px",64))
            s.disp_color.setText(d.get("pixel_color","#00aaff"));s.disp_bg.setText(d.get("background_color","#000510"))
            if "region" in d:s.disp_region=d["region"]
            ii=s.disp_iface.findText(d.get("interface","i2c"))
            if ii>=0:s.disp_iface.setCurrentIndex(ii)
            s.disp_addr.setText(d.get("address","0x3C"))
        s._save_undo();s._rl();s.canvas.update();s.canvas.center_view()

    def keyPressEvent(s,e):
        if e.modifiers()==Qt.ControlModifier:
            if e.key()==Qt.Key_Z:s._do_undo();return
            if e.key()==Qt.Key_S:s._export();return
            if e.key()==Qt.Key_D:s._dup_item(s.sel_type,s.sel_idx);return
        if e.modifiers()==(Qt.ControlModifier|Qt.ShiftModifier):
            if e.key()==Qt.Key_Z:s._do_redo();return
        super().keyPressEvent(e)

def main():
    app=QApplication(sys.argv);app.setStyle("Fusion")
    _resolve_fonts()
    pal=QPalette()
    pal.setColor(QPalette.Window,QColor(T.bg));pal.setColor(QPalette.WindowText,QColor(T.text))
    pal.setColor(QPalette.Base,QColor(T.panel));pal.setColor(QPalette.Text,QColor(T.text))
    pal.setColor(QPalette.Button,QColor(T.panel));pal.setColor(QPalette.ButtonText,QColor(T.text))
    pal.setColor(QPalette.Highlight,QColor(T.orange));pal.setColor(QPalette.HighlightedText,QColor("#000"))
    app.setPalette(pal);win=DeviceCreator();win.show();sys.exit(app.exec_())

if __name__=="__main__":main()
