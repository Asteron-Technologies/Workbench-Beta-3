# Asteron Workbench v2.1
**By Asteron Technologies**

## Quick Start (Windows)
1. `Install_Dependencies.bat` (one-time)
2. `Workbench_IDE.bat` — circuit simulator
3. `Workbench_DeviceCreator.bat` — device file builder

## IDE v2.1 — New Features
- **Project save/load** (.awp files) with Ctrl+S / Ctrl+O
- **Auto-save** (1 min) with crash recovery prompt on startup
- **Undo/redo** on canvas (Ctrl+Z / Ctrl+Shift+Z)
- **Unsaved changes warning** on close with Save/Discard/Cancel
- **Wire color by pin type** — power=red, ground=gray, analog=green, digital=blue, signal=orange
- **Component snap-to-grid** — 8px grid alignment for precision
- **Duplicate component** — Ctrl+D or right-click → Duplicate
- **Right-click context menu** — duplicate, delete, fit all
- **Fit All** (Home key) — reset camera to show all components
- **Component labels** — always shown under image-based devices
- **Formatted properties panel** — colored HTML with pin dots, headers
- **Recent Projects** menu — quick access to last 8 projects
- **Menu bar** — File (New/Open/Save/Import), Edit (Undo/Redo/Duplicate/Delete), Simulation (Run/Stop)
- **Tooltips** on all toolbar buttons and controls
- **Cross-platform fonts** — fallbacks for Linux/Mac (DejaVu, Menlo, etc.)
- **Window icon** — 4 brand-color dots
- **▶ Run / ■ Stop** buttons with symbols
- **Orange ASTERON** branding (was blue)

## Device Creator v2.1 — New Features
- **Pin rotation** (0°/90°/180°/270°) with R key, buttons, dropdown, right-click
- **Pin direction stubs** that rotate with the pin
- **Image sizing persists to export** — resized in Creator, correct in IDE
- **Image offset** — drag or oX/oY spinboxes
- **Auto-save** (1 min) with crash recovery
- **Unsaved changes warning** on close
- **Device ID validation** — must be alphanumeric+underscore, starts with letter
- **Pin bounds warning** — alerts when pins placed outside device area
- **Pin snap-to-edges** — auto-snaps within 6px of device boundary
- **Auto-increment pin numbering** — finds next available number
- **Export validation warnings** — empty IDs, duplicate pin IDs, zero pins
- **Recent files** tracking
- **Cross-platform fonts** — works on Linux, Mac, Windows
- **Tool keyboard shortcuts**: 1=Select, 2=Pin, 3=LED, 4=Display, 5=Move Image

## Keyboard Shortcuts

### IDE
| Key | Action |
|-----|--------|
| 1/2/3 | Select/Wire/Delete tool |
| Ctrl+N | New project |
| Ctrl+O | Open project |
| Ctrl+S | Save project |
| Ctrl+Z | Undo |
| Ctrl+Shift+Z | Redo |
| Ctrl+D | Duplicate selected |
| Del | Delete selected |
| Home | Fit all in view |
| F5 | Run simulation |
| Shift+F5 | Stop simulation |
| Esc | Cancel wire |
| Middle-click | Pan |
| Scroll | Zoom |

### Device Creator
| Key | Action |
|-----|--------|
| 1-5 | Select tool |
| R | Rotate selected pin +90° |
| G | Toggle grid |
| Del | Delete selected |
| Space+drag | Pan canvas |
| Scroll | Zoom |
| Home | Reset view |
| Ctrl+Z | Undo |
| Ctrl+Shift+Z | Redo |
| Ctrl+D | Duplicate |
| Ctrl+S | Export |

## Fixed Issues (from v2.0)
- Image resize now persists through export → import → IDE display
- Pin rotation exported and read correctly by IDE
- Cross-platform font resolution (was Windows-only)
- Device ID validation prevents broken JSON
- Auto-save prevents data loss from crashes
- Unsaved changes warning prevents accidental close
- Pin auto-numbering handles gaps correctly
- Wire colors indicate pin type for better readability
