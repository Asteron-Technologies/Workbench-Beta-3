#!/usr/bin/env python3
"""
Asteron Workbench — IDE & Circuit Simulator v2.1
Load .adev device files, place components, wire them, write Arduino code, and simulate.

Major features:
- Project save/load (.awp files) with auto-save crash recovery
- Full undo/redo on canvas (Ctrl+Z / Ctrl+Shift+Z)
- Wire color by pin type (power=red, ground=gray, analog=green, etc.)
- Component snap-to-grid, duplicate, multi-tool
- Unsaved changes warning on close
- Cross-platform font fallbacks
- Formatted properties panel
- Recent files menu
- Tooltips throughout

Color scheme: Blue #4a9eff | Red #ff4d4d | Green #44dd66 | Orange #ff9933
Install: pip install PyQt5
"""
import sys, os, json, math, random, re, base64, copy, tempfile, time
from pathlib import Path
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QLineEdit, QSpinBox, QComboBox,
    QPlainTextEdit, QTextEdit, QTabWidget, QTreeWidget, QTreeWidgetItem,
    QScrollArea, QSplitter, QFileDialog, QMessageBox, QFrame,
    QSizePolicy, QStatusBar, QMenu, QAction, QToolTip
)
from PyQt5.QtCore import Qt, QTimer, QPointF, QRectF, pyqtSignal, QPoint, QSize, QSettings
from PyQt5.QtGui import (
    QPainter, QColor, QFont, QPen, QBrush, QRadialGradient,
    QImage, QPalette, QFontMetrics, QPainterPath, QPixmap,
    QSyntaxHighlighter, QTextCharFormat, QIcon, QFontDatabase
)

# ═══════════════════ PLATFORM FONTS ═══════════════════
def _mono_font():
    """Return best available monospace font for this platform."""
    try:
        avail = QFontDatabase().families()
        for name in ["Consolas", "SF Mono", "Menlo", "DejaVu Sans Mono", "Liberation Mono", "Courier New"]:
            if name in avail: return name
    except Exception:
        pass
    return "monospace"

def _ui_font():
    """Return best available UI font for this platform."""
    try:
        avail = QFontDatabase().families()
        for name in ["Segoe UI", "SF Pro Display", "Helvetica Neue", "Ubuntu", "Noto Sans", "Arial"]:
            if name in avail: return name
    except Exception:
        pass
    return "sans-serif"

def _make_icon():
    """Create a 32x32 programmatic icon with 4 brand dots."""
    pm = QPixmap(32, 32); pm.fill(QColor("#0c0c0e"))
    p = QPainter(pm); p.setRenderHint(QPainter.Antialiasing)
    for (cx, cy), cl in zip([(10,10),(22,10),(10,22),(22,22)],
                            ["#4a9eff","#ff4d4d","#44dd66","#ff9933"]):
        p.setBrush(QBrush(QColor(cl))); p.setPen(Qt.NoPen)
        p.drawEllipse(QPointF(cx, cy), 4, 4)
    p.end(); return QIcon(pm)

# ═══════════════════ THEME ═══════════════════
class T:
    """Color and typography theme constants."""
    bg = "#0c0c0e"; panel = "#131316"; panelAlt = "#18181c"
    surface = "#1c1c22"; surfHov = "#242430"
    border = "#222230"; borderL = "#2a2a38"
    blue = "#4a9eff"; blueDim = "#1a2844"
    red = "#ff4d4d"; redDim = "#3a1818"
    green = "#44dd66"; greenDim = "#163322"
    orange = "#ff9933"; orangeDim = "#332211"
    text = "#d4d4dc"; textSec = "#8888a0"; textMut = "#505068"
    R = 4

# Resolved at app start
T.MONO = "Consolas"
T.UI = "Segoe UI"

PIN_CLR = {
    "digital": T.blue, "analog": T.green, "power": T.red,
    "ground": "#666680", "gnd": "#666680", "signal": T.orange,
    "passive": "#808090", "i2c_sda": T.orange, "i2c_scl": T.orange,
    "spi_mosi": T.blue, "spi_miso": T.blue, "spi_sck": T.blue,
    "serial_tx": "#cc66ff", "serial_rx": "#cc66ff"
}

def _build_ss():
    """Build stylesheet with resolved font names."""
    return (
        "QMainWindow{background:"+T.bg+"}"
        "QMenuBar{background:"+T.panel+";color:"+T.text+";border-bottom:1px solid "+T.border+";font-size:12px}"
        "QMenuBar::item:selected{background:"+T.surfHov+"}"
        "QMenu{background:"+T.surface+";color:"+T.text+";border:1px solid "+T.border+"}"
        "QMenu::item:selected{background:"+T.blue+";color:#000}"
        "QToolBar{background:"+T.panel+";border-bottom:1px solid "+T.border+";spacing:6px;padding:4px 8px}"
        "QStatusBar{background:"+T.panel+";color:"+T.textMut+";border-top:1px solid "+T.border+"}"
        "QSplitter::handle{background:"+T.border+";width:2px}"
        "QTreeWidget{background:"+T.panel+";color:"+T.text+";border:none;font-size:12px;outline:none}"
        "QTreeWidget::item{padding:4px 8px;margin:1px 4px}"
        "QTreeWidget::item:hover{background:"+T.surfHov+"}"
        "QTreeWidget::item:selected{background:"+T.blueDim+";color:"+T.blue+"}"
        "QTreeWidget::branch{background:"+T.panel+"}"
        "QTabWidget::pane{background:"+T.panel+";border:none;border-top:1px solid "+T.border+"}"
        "QTabBar::tab{background:"+T.panel+";color:"+T.textMut+";padding:7px 16px;border-bottom:2px solid transparent;font-family:"+T.MONO+";font-size:11px}"
        "QTabBar::tab:selected{color:"+T.orange+";border-bottom-color:"+T.orange+"}"
        "QTabBar::tab:hover{color:"+T.text+"}"
        "QPlainTextEdit,QTextEdit{background:"+T.bg+";color:#c8c8dc;border:none;font-family:"+T.MONO+";font-size:13px;selection-background-color:rgba(74,158,255,0.25)}"
        "QPushButton{background:"+T.surface+";color:"+T.text+";border:1px solid "+T.border+";border-radius:4px;padding:6px 14px;font-size:11px;font-weight:bold}"
        "QPushButton:hover{background:"+T.surfHov+";border-color:"+T.blue+"}"
        "QPushButton:checked{background:"+T.blueDim+";border-color:"+T.blue+";color:"+T.blue+"}"
        "QLabel{color:"+T.text+"}"
        "QScrollBar:vertical{background:"+T.bg+";width:8px}"
        "QScrollBar::handle:vertical{background:"+T.border+";min-height:30px;border-radius:4px}"
        "QScrollBar::add-line:vertical,QScrollBar::sub-line:vertical{height:0}"
    )

# ═══════════════════ UNDO STACK ═══════════════════
class UndoStack:
    """Generic undo/redo stack storing deep copies of state."""
    def __init__(self, max_states=60):
        self._states = []
        self._index = -1
        self._max = max_states

    def push(self, state):
        """Push a new state, discarding any redo history."""
        self._states = self._states[:self._index + 1]
        self._states.append(copy.deepcopy(state))
        if len(self._states) > self._max:
            self._states.pop(0)
        self._index = len(self._states) - 1

    def undo(self):
        if self._index > 0:
            self._index -= 1
            return copy.deepcopy(self._states[self._index])
        return None

    def redo(self):
        if self._index < len(self._states) - 1:
            self._index += 1
            return copy.deepcopy(self._states[self._index])
        return None

    def can_undo(self): return self._index > 0
    def can_redo(self): return self._index < len(self._states) - 1

# ═══════════════════ DEVICE LOADER ═══════════════════
class DevPin:
    """Represents a single pin on a device."""
    def __init__(self, data):
        self.id = data.get("id", "")
        self.label = data.get("label", "")
        self.x = data.get("x", 0)
        self.y = data.get("y", 0)
        self.side = data.get("side", "left")
        self.type = data.get("type", "digital")
        self.direction = data.get("direction", "io")
        self.notes = data.get("notes", "")
        self.shape = data.get("shape", "circle")
        self.size = data.get("size", 4)
        self.rotation = data.get("rotation", 0)

class DeviceDef:
    """Parsed device definition from .adev file."""
    def __init__(self, data):
        try:
            dev = data.get("device", {})
            vis = data.get("visual", {})
            emu = data.get("emulation", {})
            self.id = dev.get("id", "?")
            self.name = dev.get("name", "?")
            self.category = dev.get("category", "Other")
            self.desc = dev.get("description", "")
            self.w = vis.get("width", 60)
            self.h = vis.get("height", 60)
            self.label = vis.get("label", self.name)
            self.color = vis.get("color", "#555")
            self.image_svg = vis.get("image_svg", None)
            self.pins = [DevPin(p) for p in data.get("pins", [])]
            self.img_dw = vis.get("image_display_width", self.w)
            self.img_dh = vis.get("image_display_height", self.h)
            self.img_ox = vis.get("image_offset_x", 0)
            self.img_oy = vis.get("image_offset_y", 0)
            self.emu_type = emu.get("type", "passive")
            self.state_vars = dict(emu.get("state_vars", {}))
            self.rules = list(emu.get("rules", []))
            self.props = dict(emu.get("properties", {}))
            self.display = data.get("display", None)
            self.leds = vis.get("led_indicators", [])
            self.raw = data
            self._qimage = None
            if self.image_svg:
                m = re.search(r"data:image/[^;]+;base64,([A-Za-z0-9+/=\s]+)", self.image_svg)
                if m:
                    try:
                        raw = base64.b64decode(m.group(1))
                        img = QImage()
                        img.loadFromData(raw)
                        if not img.isNull():
                            self._qimage = img
                    except Exception:
                        pass
        except Exception as ex:
            raise ValueError(f"Invalid device data: {ex}")

# ═══════════════════ SYNTAX HIGHLIGHTER ═══════════════════
class ArduinoHighlighter(QSyntaxHighlighter):
    """Arduino/C++ syntax highlighting for the code editor."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.rules = []
        # Keywords
        kw_fmt = QTextCharFormat()
        kw_fmt.setForeground(QColor("#c792ea"))
        kw_fmt.setFontWeight(QFont.Bold)
        keywords = [
            "void","int","long","float","double","char","bool","boolean","byte",
            "String","unsigned","const","static","return","if","else","for","while",
            "do","switch","case","break","continue","class","struct","true","false",
            "NULL","#include","#define"
        ]
        for kw in keywords:
            pat = rf"\b{re.escape(kw)}\b" if not kw.startswith("#") else re.escape(kw)
            self.rules.append((re.compile(pat), kw_fmt))
        # Functions
        fn_fmt = QTextCharFormat()
        fn_fmt.setForeground(QColor("#82aaff"))
        funcs = [
            "pinMode","digitalWrite","digitalRead","analogWrite","analogRead",
            "Serial","begin","print","println","delay","millis","map","constrain",
            "tone","noTone","INPUT","OUTPUT","INPUT_PULLUP","HIGH","LOW",
            "setup","loop","Servo","attach","write"
        ]
        for fn in funcs:
            self.rules.append((re.compile(rf"\b{fn}\b"), fn_fmt))
        # Strings
        str_fmt = QTextCharFormat()
        str_fmt.setForeground(QColor("#c3e88d"))
        self.rules.append((re.compile(r'"[^"]*"'), str_fmt))
        # Numbers
        num_fmt = QTextCharFormat()
        num_fmt.setForeground(QColor("#f78c6c"))
        self.rules.append((re.compile(r"\b\d+\.?\d*\b"), num_fmt))
        # Comments
        cmt_fmt = QTextCharFormat()
        cmt_fmt.setForeground(QColor("#546e7a"))
        self.rules.append((re.compile(r"//.*$"), cmt_fmt))

    def highlightBlock(self, text):
        for pat, fmt in self.rules:
            for m in pat.finditer(text):
                self.setFormat(m.start(), m.end() - m.start(), fmt)

# ═══════════════════ CODE EDITOR ═══════════════════
class LineNumArea(QWidget):
    """Gutter widget showing line numbers for the code editor."""
    def __init__(self, editor):
        super().__init__(editor)
        self.editor = editor
    def sizeHint(self):
        return QSize(self.editor.gutter_width(), 0)
    def paintEvent(self, event):
        self.editor.paint_gutter(event)

class CodeEditor(QPlainTextEdit):
    """Code editor with line numbers and syntax highlighting."""
    def __init__(self):
        super().__init__()
        self.gutter = LineNumArea(self)
        self.blockCountChanged.connect(lambda _: self._update_margins())
        self.updateRequest.connect(self._update_gutter)
        self._update_margins()
        self.setFont(QFont(T.MONO, 13))
        self.setTabStopDistance(QFontMetrics(self.font()).horizontalAdvance(" ") * 4)
        self.highlighter = ArduinoHighlighter(self.document())

    def gutter_width(self):
        digits = max(1, len(str(self.blockCount())))
        return 14 + QFontMetrics(self.font()).horizontalAdvance("9") * digits

    def _update_margins(self):
        self.setViewportMargins(self.gutter_width(), 0, 0, 0)

    def _update_gutter(self, rect, dy):
        if dy:
            self.gutter.scroll(0, dy)
        else:
            self.gutter.update(0, rect.y(), self.gutter.width(), rect.height())

    def resizeEvent(self, event):
        super().resizeEvent(event)
        cr = self.contentsRect()
        self.gutter.setGeometry(cr.left(), cr.top(), self.gutter_width(), cr.height())

    def paint_gutter(self, event):
        painter = QPainter(self.gutter)
        painter.fillRect(event.rect(), QColor(T.panel))
        painter.setPen(QPen(QColor(T.border)))
        gw = self.gutter.width()
        painter.drawLine(gw - 1, event.rect().top(), gw - 1, event.rect().bottom())
        block = self.firstVisibleBlock()
        top = round(self.blockBoundingGeometry(block).translated(self.contentOffset()).top())
        bot = top + round(self.blockBoundingRect(block).height())
        painter.setFont(QFont(T.MONO, 9))
        fh = self.fontMetrics().height()
        while block.isValid() and top <= event.rect().bottom():
            if block.isVisible() and bot >= event.rect().top():
                painter.setPen(QColor(T.textMut))
                painter.drawText(0, top, gw - 6, fh, Qt.AlignRight, str(block.blockNumber() + 1))
            block = block.next()
            top = bot
            bot = top + round(self.blockBoundingRect(block).height())

# ═══════════════════ CIRCUIT CANVAS ═══════════════════
_uid_counter = 0
def _next_id():
    """Generate a unique instance/wire ID."""
    global _uid_counter
    _uid_counter += 1
    return f"i{_uid_counter}"

class CircuitCanvas(QWidget):
    """Main circuit editing canvas with pan, zoom, snapping, wiring, and undo."""
    selectionChanged = pyqtSignal(object)

    SNAP = 8  # Grid snap size in device units

    def __init__(self):
        super().__init__()
        self.setMouseTracking(True)
        self.setFocusPolicy(Qt.StrongFocus)
        self.instances = []    # Placed component instances
        self.wires = []        # Wire connections
        self.camera = QPointF(0, 0)
        self.zoom_level = 1.0
        self.selected = None   # Selected instance ID
        self.tool = "select"
        self.dragging = None   # Drag state for moving components
        self.panning = None    # Pan state for camera movement
        self.connecting = None # Wire-in-progress start pin
        self.wire_points = []  # Waypoints for wire being drawn
        self.mouse_world = QPointF(0, 0)
        self.sim_running = False
        self.undo_stack = UndoStack()
        self._dirty = False
        self._init_undo()

    def _init_undo(self):
        """Push initial empty state."""
        self.undo_stack.push(self._get_state())

    def _get_state(self):
        """Capture current canvas state for undo."""
        return {
            "instances": [{
                "id": inst["id"], "dev_id": inst["dev"].id,
                "x": inst["x"], "y": inst["y"],
                "state": dict(inst["state"])
            } for inst in self.instances],
            "wires": copy.deepcopy(self.wires)
        }

    def save_undo(self):
        """Push current state to undo stack and mark dirty."""
        self.undo_stack.push(self._get_state())
        self._dirty = True

    def to_world(self, pos):
        """Convert widget coordinates to world coordinates."""
        return QPointF(pos.x() / self.zoom_level - self.camera.x(),
                       pos.y() / self.zoom_level - self.camera.y())

    def snap(self, value):
        """Snap a coordinate to the grid."""
        return round(value / self.SNAP) * self.SNAP

    def add_instance(self, dev):
        """Place a new device instance on the canvas."""
        x = self.snap(-self.camera.x() + 300 + random.randint(-40, 40))
        y = self.snap(-self.camera.y() + 200 + random.randint(-40, 40))
        inst = {
            "id": _next_id(), "dev": dev,
            "x": x, "y": y,
            "state": dict(dev.state_vars)
        }
        self.instances.append(inst)
        self.selected = inst["id"]
        self.save_undo()
        self.update()
        return inst

    def delete_selected(self):
        """Delete the currently selected instance and its wires."""
        if not self.selected:
            return
        self.instances = [i for i in self.instances if i["id"] != self.selected]
        self.wires = [w for w in self.wires
                      if w["from"][0] != self.selected and w["to"][0] != self.selected]
        self.selected = None
        self.save_undo()
        self.update()

    def duplicate_selected(self):
        """Duplicate the currently selected instance."""
        if not self.selected:
            return
        src = next((i for i in self.instances if i["id"] == self.selected), None)
        if not src:
            return
        inst = {
            "id": _next_id(), "dev": src["dev"],
            "x": src["x"] + 30, "y": src["y"] + 30,
            "state": dict(src["dev"].state_vars)
        }
        self.instances.append(inst)
        self.selected = inst["id"]
        self.save_undo()
        self.selectionChanged.emit(inst)
        self.update()

    def find_pin_at(self, wx, wy):
        """Find a pin near the given world coordinates."""
        for inst in reversed(self.instances):
            for pin in inst["dev"].pins:
                px = inst["x"] + pin.x
                py = inst["y"] + pin.y
                threshold = 9 * max(1, 1 / self.zoom_level)
                if math.hypot(wx - px, wy - py) < threshold:
                    return inst["id"], pin, px, py
        return None

    def find_inst_at(self, wx, wy):
        """Find a component instance at the given world coordinates."""
        for inst in reversed(self.instances):
            dev = inst["dev"]
            if (inst["x"] <= wx <= inst["x"] + dev.w and
                inst["y"] <= wy <= inst["y"] + dev.h):
                return inst
        return None

    def get_wire_route(self, wire):
        """Get the list of points for a wire, including start, waypoints, and end."""
        from_inst = next((i for i in self.instances if i["id"] == wire["from"][0]), None)
        to_inst = next((i for i in self.instances if i["id"] == wire["to"][0]), None)
        if not from_inst or not to_inst:
            return []
        from_pin = next((p for p in from_inst["dev"].pins if p.id == wire["from"][1]), None)
        to_pin = next((p for p in to_inst["dev"].pins if p.id == wire["to"][1]), None)
        if not from_pin or not to_pin:
            return []
        sx, sy = from_inst["x"] + from_pin.x, from_inst["y"] + from_pin.y
        ex, ey = to_inst["x"] + to_pin.x, to_inst["y"] + to_pin.y
        waypoints = wire.get("waypoints", [])
        return [(sx, sy)] + list(waypoints) + [(ex, ey)]

    def get_wire_color(self, wire):
        """Determine wire color based on the source pin type."""
        from_inst = next((i for i in self.instances if i["id"] == wire["from"][0]), None)
        if from_inst:
            from_pin = next((p for p in from_inst["dev"].pins if p.id == wire["from"][1]), None)
            if from_pin:
                return QColor(PIN_CLR.get(from_pin.type, T.blue))
        return QColor(T.blue)

    def fit_all(self):
        """Reset camera to fit all instances in view."""
        if not self.instances:
            self.camera = QPointF(0, 0)
            self.zoom_level = 1.0
            self.update()
            return
        min_x = min(i["x"] for i in self.instances) - 50
        min_y = min(i["y"] for i in self.instances) - 50
        max_x = max(i["x"] + i["dev"].w for i in self.instances) + 50
        max_y = max(i["y"] + i["dev"].h for i in self.instances) + 50
        scene_w = max_x - min_x
        scene_h = max_y - min_y
        if scene_w < 1 or scene_h < 1:
            return
        zx = self.width() / scene_w
        zy = self.height() / scene_h
        self.zoom_level = max(0.25, min(4.0, min(zx, zy) * 0.9))
        self.camera = QPointF(
            -min_x + (self.width() / self.zoom_level - scene_w) / 2,
            -min_y + (self.height() / self.zoom_level - scene_h) / 2
        )
        self.update()

    # ── Paint ──
    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        W, H = self.width(), self.height()
        p.fillRect(0, 0, W, H, QColor(T.bg))
        p.save()
        p.scale(self.zoom_level, self.zoom_level)
        p.translate(self.camera)

        # Grid dots
        sp = 20
        p.setPen(QPen(QColor("#ffffff0d"), 1))
        vw = W / self.zoom_level
        vh = H / self.zoom_level
        cx, cy = self.camera.x(), self.camera.y()
        x0 = int(-cx / sp) * sp - sp
        y0 = int(-cy / sp) * sp - sp
        gx = x0
        while gx < -cx + vw + sp:
            gy = y0
            while gy < -cy + vh + sp:
                p.drawPoint(QPointF(gx, gy))
                gy += sp
            gx += sp

        # Completed wires — colored by pin type
        for wire in self.wires:
            route = self.get_wire_route(wire)
            if len(route) < 2:
                continue
            if self.sim_running:
                col = QColor(T.green)
            else:
                col = self.get_wire_color(wire)
            p.setPen(QPen(col, 2.5, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin))
            path = QPainterPath()
            path.moveTo(route[0][0], route[0][1])
            for pt in route[1:]:
                path.lineTo(pt[0], pt[1])
            p.drawPath(path)
            # Junction dots
            p.setBrush(QBrush(col))
            p.setPen(Qt.NoPen)
            for pt in route:
                p.drawEllipse(QPointF(pt[0], pt[1]), 3, 3)

        # Wire in progress
        if self.connecting:
            cx0, cy0 = self.connecting[2], self.connecting[3]
            mx_w, my_w = self.mouse_world.x(), self.mouse_world.y()
            hit = self.find_pin_at(mx_w, my_w)
            if hit:
                mx_w, my_w = hit[2], hit[3]
            pts = [(cx0, cy0)] + list(self.wire_points) + [(mx_w, my_w)]
            p.setPen(QPen(QColor(T.orange), 2.0, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin))
            path = QPainterPath()
            path.moveTo(pts[0][0], pts[0][1])
            for pt in pts[1:]:
                path.lineTo(pt[0], pt[1])
            p.drawPath(path)
            p.setBrush(QBrush(QColor(T.orange)))
            p.setPen(Qt.NoPen)
            p.drawEllipse(QPointF(cx0, cy0), 5, 5)
            for wp in self.wire_points:
                p.drawEllipse(QPointF(wp[0], wp[1]), 4, 4)
            p.setBrush(QBrush(QColor(T.orange + "88")))
            p.drawEllipse(QPointF(mx_w, my_w), 4, 4)
            p.setPen(QColor(T.orange + "aa"))
            p.setFont(QFont(T.MONO, 7))
            p.drawText(QPointF(mx_w + 8, my_w - 8),
                       "click pin = finish | R-click = waypoint | Esc = cancel")

        # Instances
        for inst in self.instances:
            dev = inst["dev"]
            ix, iy = inst["x"], inst["y"]
            p.save()
            p.translate(ix, iy)

            # Selection highlight
            if inst["id"] == self.selected:
                p.setPen(QPen(QColor(T.blue), 1.5, Qt.DashLine))
                p.setBrush(Qt.NoBrush)
                p.drawRoundedRect(QRectF(-5, -5, dev.w + 10, dev.h + 10), 4, 4)

            is_board = dev.emu_type == "microcontroller"

            # Render device body
            if dev._qimage:
                p.drawImage(QRectF(dev.img_ox, dev.img_oy, dev.img_dw, dev.img_dh), dev._qimage)
            elif is_board:
                p.setBrush(QBrush(QColor("#0b3d1a")))
                p.setPen(QPen(QColor("#1a7a3a"), 1.5))
                p.drawRoundedRect(QRectF(8, 0, dev.w - 16, dev.h), 4, 4)
                p.setBrush(QBrush(QColor("#081410")))
                p.setPen(Qt.NoPen)
                p.drawRoundedRect(QRectF(14, 6, dev.w - 28, 24), 2, 2)
                p.setPen(QColor(T.blue))
                p.setFont(QFont(T.MONO, 10, QFont.Bold))
                p.drawText(QRectF(14, 6, dev.w - 28, 24), Qt.AlignCenter, dev.label)
                chip_w = min(50, dev.w * 0.35)
                chip_h = min(80, dev.h * 0.28)
                p.setBrush(QBrush(QColor("#0a0a0a")))
                p.setPen(QPen(QColor("#2a2a2a"), 0.8))
                p.drawRect(QRectF((dev.w - chip_w) / 2, dev.h * 0.32, chip_w, chip_h))
                p.setBrush(QBrush(QColor("#222")))
                p.setPen(QPen(QColor("#444"), 0.8))
                p.drawRoundedRect(QRectF((dev.w - 36) / 2, dev.h - 14, 36, 14), 2, 2)
                p.setPen(QColor(T.textMut))
                p.setFont(QFont(T.MONO, 7))
                p.drawText(QRectF((dev.w - 36) / 2, dev.h - 14, 36, 14), Qt.AlignCenter, "USB")
            elif dev.display:
                p.setBrush(QBrush(QColor("#111418")))
                p.setPen(QPen(QColor("#2a2d33"), 1))
                p.drawRoundedRect(QRectF(0, 0, dev.w, dev.h), T.R, T.R)
                dr = dev.display.get("region", {})
                rx, ry = dr.get("x", 4), dr.get("y", 4)
                rw, rh = dr.get("w", dev.w - 8), dr.get("h", dev.h - 16)
                p.setBrush(QBrush(QColor(dev.display.get("background_color", "#000510"))))
                p.setPen(Qt.NoPen)
                p.drawRect(QRectF(rx, ry, rw, rh))
                p.setPen(QColor(T.textMut))
                p.setFont(QFont(T.MONO, 7))
                p.drawText(QRectF(0, dev.h - 12, dev.w, 12), Qt.AlignCenter, dev.label)
            else:
                p.setBrush(QBrush(QColor(dev.color)))
                p.setPen(QPen(QColor(T.borderL), 1))
                p.drawRoundedRect(QRectF(0, 0, dev.w, dev.h), T.R, T.R)

            # LED indicators
            for led in dev.leds:
                sv = led.get("state_var", "")
                on_val = led.get("on_value", True)
                is_on = self.sim_running and inst["state"].get(sv) == on_val
                lx, ly, lr = led.get("x", 0), led.get("y", 0), led.get("radius", 6)
                lc = QColor(led.get("color", "#ff3344"))
                if is_on:
                    grad = QRadialGradient(lx, ly, lr * 3)
                    grad.setColorAt(0, QColor(lc.red(), lc.green(), lc.blue(), 180))
                    grad.setColorAt(1, QColor(lc.red(), lc.green(), lc.blue(), 0))
                    p.setBrush(QBrush(grad))
                    p.setPen(Qt.NoPen)
                    p.drawEllipse(QPointF(lx, ly), lr * 3, lr * 3)
                fill = QColor(lc) if is_on else QColor(lc.red()//4, lc.green()//4, lc.blue()//4, 120)
                border_c = lc if is_on else QColor(lc.red()//3, lc.green()//3, lc.blue()//3)
                p.setBrush(QBrush(fill))
                p.setPen(QPen(border_c, 1))
                p.drawEllipse(QPointF(lx, ly), lr, lr)

            # Pins
            for pin in dev.pins:
                pc = QColor(PIN_CLR.get(pin.type, "#808090"))
                wpx, wpy = ix + pin.x, iy + pin.y
                dist = math.hypot(self.mouse_world.x() - wpx, self.mouse_world.y() - wpy)
                is_hov = dist < 9
                r = 6 if is_hov else 4
                fc = QColor(T.blue) if is_hov else pc
                bc = QColor(T.blue + "88") if is_hov else QColor(pc.red(), pc.green(), pc.blue(), 80)
                p.setBrush(QBrush(fc))
                p.setPen(QPen(bc, 1))
                p.drawEllipse(QPointF(pin.x, pin.y), r, r)
                if is_board:
                    p.setPen(QColor(T.textMut))
                    p.setFont(QFont(T.MONO, 7))
                    if pin.side == "left":
                        p.drawText(QPointF(pin.x + 8, pin.y + 3), pin.label)
                    else:
                        fm = QFontMetrics(p.font())
                        p.drawText(QPointF(pin.x - 8 - fm.horizontalAdvance(pin.label), pin.y + 3), pin.label)
                # Hover tooltip
                if is_hov:
                    txt = f"{pin.label} ({pin.type})"
                    p.setFont(QFont(T.MONO, 8, QFont.Bold))
                    fm = QFontMetrics(p.font())
                    tw = fm.horizontalAdvance(txt) + 10
                    p.setBrush(QBrush(QColor(0, 0, 0, 220)))
                    p.setPen(Qt.NoPen)
                    p.drawRoundedRect(QRectF(pin.x - tw/2, pin.y - 22, tw, 16), 4, 4)
                    p.setPen(QColor("#fff"))
                    p.drawText(QRectF(pin.x - tw/2, pin.y - 22, tw, 16), Qt.AlignCenter, txt)

            # Label under component (always show, even for image-based)
            if not is_board:
                p.setPen(QColor(T.textSec))
                p.setFont(QFont(T.MONO, 8, QFont.Bold))
                p.drawText(QRectF(0, dev.h + 2, dev.w, 14), Qt.AlignCenter, dev.label)

            p.restore()

        # Empty canvas hint
        if not self.instances:
            p.setPen(QColor(T.textMut))
            p.setFont(QFont(T.MONO, 12))
            p.drawText(QPointF(-self.camera.x() + vw/2 - 200, -self.camera.y() + vh/2),
                       "Import .adev files, then click devices to place")

        p.restore()

        # HUD overlay
        p.setPen(QColor(T.textMut))
        p.setFont(QFont(T.MONO, 9))
        p.drawText(8, H - 8, f"{self.zoom_level:.1f}x")
        if self.undo_stack.can_undo() or self.undo_stack.can_redo():
            u = "U" if self.undo_stack.can_undo() else "-"
            r = "R" if self.undo_stack.can_redo() else "-"
            p.drawText(60, H - 8, f"[{u}/{r}]")

    # ── Mouse ──
    def mousePressEvent(self, event):
        w = self.to_world(event.pos())
        if event.button() == Qt.MiddleButton:
            self.panning = {"start": event.pos(), "cam": QPointF(self.camera)}
            self.setCursor(Qt.ClosedHandCursor)
            return
        if event.button() == Qt.RightButton:
            if self.connecting:
                self.wire_points.append((self.snap(w.x()), self.snap(w.y())))
                self.update()
            else:
                self._context_menu(event.pos(), w)
            return
        if event.button() != Qt.LeftButton:
            return

        hit = self.find_pin_at(w.x(), w.y())

        # Wire tool
        if self.tool == "wire":
            if hit:
                iid, pin, px, py = hit
                if not self.connecting:
                    self.connecting = (iid, pin, px, py)
                    self.wire_points = []
                else:
                    if self.connecting[0] != iid or self.connecting[1].id != pin.id:
                        self.wires.append({
                            "id": _next_id(),
                            "from": (self.connecting[0], self.connecting[1].id),
                            "to": (iid, pin.id),
                            "waypoints": list(self.wire_points)
                        })
                        self.save_undo()
                    self.connecting = None
                    self.wire_points = []
            else:
                if self.connecting:
                    self.wire_points.append((self.snap(w.x()), self.snap(w.y())))
            self.update()
            return

        # Select tool + pin = start/end wire
        if self.tool == "select" and hit:
            iid, pin, px, py = hit
            if not self.connecting:
                self.connecting = (iid, pin, px, py)
                self.wire_points = []
            else:
                if self.connecting[0] != iid or self.connecting[1].id != pin.id:
                    self.wires.append({
                        "id": _next_id(),
                        "from": (self.connecting[0], self.connecting[1].id),
                        "to": (iid, pin.id),
                        "waypoints": list(self.wire_points)
                    })
                    self.save_undo()
                self.connecting = None
                self.wire_points = []
            self.update()
            return

        # Delete tool
        if self.tool == "delete":
            inst = self.find_inst_at(w.x(), w.y())
            if inst:
                self.instances.remove(inst)
                self.wires = [wi for wi in self.wires
                              if wi["from"][0] != inst["id"] and wi["to"][0] != inst["id"]]
                if self.selected == inst["id"]:
                    self.selected = None
                self.save_undo()
                self.update()
                return
            # Check wire hit
            for wi in list(self.wires):
                route = self.get_wire_route(wi)
                for i in range(len(route) - 1):
                    ax, ay = route[i]
                    bx, by = route[i + 1]
                    dx, dy = bx - ax, by - ay
                    l2 = dx*dx + dy*dy
                    t = max(0, min(1, ((w.x()-ax)*dx + (w.y()-ay)*dy) / l2)) if l2 > 0 else 0
                    if math.hypot(w.x() - (ax + t*dx), w.y() - (ay + t*dy)) < 8:
                        self.wires.remove(wi)
                        self.save_undo()
                        self.update()
                        return
            return

        # Select — cancel wire or drag/pan
        if self.connecting:
            self.connecting = None
            self.wire_points = []
            self.update()
            return
        inst = self.find_inst_at(w.x(), w.y())
        if inst:
            self.selected = inst["id"]
            self.dragging = {"id": inst["id"], "ox": w.x() - inst["x"], "oy": w.y() - inst["y"]}
            self.selectionChanged.emit(inst)
        else:
            self.selected = None
            self.panning = {"start": event.pos(), "cam": QPointF(self.camera)}
            self.selectionChanged.emit(None)
        self.update()

    def _context_menu(self, pos, world):
        """Show right-click context menu."""
        menu = QMenu(self)
        menu.setStyleSheet(
            "QMenu{background:"+T.surface+";color:"+T.text+";border:1px solid "+T.border+";"
            "border-radius:4px;padding:4px}"
            "QMenu::item{padding:6px 20px}"
            "QMenu::item:selected{background:"+T.blue+";color:#000}")
        inst = self.find_inst_at(world.x(), world.y())
        if inst:
            menu.addAction(f"Duplicate {inst['dev'].name}", lambda: self._ctx_dup(inst))
            menu.addAction(f"Delete {inst['dev'].name}", lambda: self._ctx_del_inst(inst))
        # Check for wire near cursor
        for wi in self.wires:
            route = self.get_wire_route(wi)
            for i in range(len(route) - 1):
                ax, ay = route[i]
                bx, by = route[i + 1]
                dx, dy = bx - ax, by - ay
                l2 = dx*dx + dy*dy
                t = max(0, min(1, ((world.x()-ax)*dx + (world.y()-ay)*dy) / l2)) if l2 > 0 else 0
                if math.hypot(world.x() - (ax + t*dx), world.y() - (ay + t*dy)) < 8:
                    wr = wi
                    menu.addAction("Delete Wire", lambda ww=wr: self._ctx_del_wire(ww))
                    break
        if not inst:
            menu.addSeparator()
            menu.addAction("Fit All (Home)", self.fit_all)
        menu.exec_(self.mapToGlobal(pos))

    def _ctx_del_inst(self, inst):
        self.instances.remove(inst)
        self.wires = [w for w in self.wires
                      if w["from"][0] != inst["id"] and w["to"][0] != inst["id"]]
        if self.selected == inst["id"]:
            self.selected = None
        self.save_undo()
        self.update()

    def _ctx_dup(self, inst):
        new_inst = {
            "id": _next_id(), "dev": inst["dev"],
            "x": inst["x"] + 30, "y": inst["y"] + 30,
            "state": dict(inst["dev"].state_vars)
        }
        self.instances.append(new_inst)
        self.selected = new_inst["id"]
        self.save_undo()
        self.selectionChanged.emit(new_inst)
        self.update()

    def _ctx_del_wire(self, wire):
        if wire in self.wires:
            self.wires.remove(wire)
            self.save_undo()
        self.update()

    def mouseMoveEvent(self, event):
        self.mouse_world = self.to_world(event.pos())
        if self.panning:
            d = event.pos() - self.panning["start"]
            self.camera = self.panning["cam"] + QPointF(d.x() / self.zoom_level, d.y() / self.zoom_level)
            self.update()
            return
        if self.dragging:
            w = self.mouse_world
            for inst in self.instances:
                if inst["id"] == self.dragging["id"]:
                    inst["x"] = self.snap(w.x() - self.dragging["ox"])
                    inst["y"] = self.snap(w.y() - self.dragging["oy"])
                    break
            self.update()
            return
        # Cursor
        if self.connecting or self.tool == "wire":
            self.setCursor(Qt.CrossCursor)
        elif self.tool == "delete":
            self.setCursor(Qt.ForbiddenCursor)
        else:
            self.setCursor(Qt.ArrowCursor)
        self.update()

    def mouseReleaseEvent(self, event):
        if self.dragging:
            self.save_undo()
            self.dragging = None
        if self.panning:
            self.panning = None
            self.setCursor(Qt.ArrowCursor)

    def wheelEvent(self, event):
        factor = 1.15 if event.angleDelta().y() > 0 else 1 / 1.15
        old_zoom = self.zoom_level
        self.zoom_level = max(0.25, min(4.0, self.zoom_level * factor))
        mx, my = event.pos().x(), event.pos().y()
        self.camera = QPointF(
            self.camera.x() + mx / self.zoom_level - mx / old_zoom,
            self.camera.y() + my / self.zoom_level - my / old_zoom
        )
        self.update()

    def keyPressEvent(self, event):
        if event.key() in (Qt.Key_Delete, Qt.Key_Backspace):
            self.delete_selected()
        elif event.key() == Qt.Key_Escape:
            self.connecting = None
            self.wire_points = []
            self.update()
        elif event.key() == Qt.Key_Home:
            self.fit_all()

# ═══════════════════ SERIAL MONITOR ═══════════════════
class SerialMonitor(QTextEdit):
    """Serial output monitor with color-coded message types."""
    def __init__(self):
        super().__init__()
        self.setReadOnly(True)
        self.setFont(QFont(T.MONO, 11))
        self.document().setDefaultStyleSheet(
            ".i{color:"+T.textMut+"}"
            ".o{color:"+T.green+"}"
            ".e{color:"+T.red+"}"
            ".p{color:"+T.blue+"}")
        self.log("Serial monitor ready.", "i")

    def log(self, text, cls="i"):
        self.append(f'<span class="{cls}">{text}</span>')

    def log_out(self, text):
        self.append(f'<span class="p">&gt; </span><span class="o">{text}</span>')

    def clear(self):
        self.setPlainText("")

# ═══════════════════ MAIN WINDOW ═══════════════════
class WorkbenchIDE(QMainWindow):
    """Main IDE window with circuit canvas, code editor, device library, and simulation."""

    def __init__(self):
        super().__init__()
        self.setWindowTitle("Asteron Workbench \u2014 IDE")
        self.setWindowIcon(_make_icon())
        self.setMinimumSize(1100, 700)
        self.resize(1400, 850)
        self.setStyleSheet(_build_ss())

        self.devices = {}          # Loaded device definitions
        self.project_path = None   # Current project save path
        self._dirty = False        # Unsaved changes flag
        self.settings = QSettings("AsteronTech", "Workbench")

        # Simulation
        self.sim_timer = QTimer()
        self.sim_timer.setInterval(500)
        self.sim_timer.timeout.connect(self._sim_tick)
        self.sim_tick_count = 0
        self._has_dw = False
        self._has_blink = False

        # Auto-save timer
        self.autosave_timer = QTimer()
        self.autosave_timer.setInterval(60000)  # 1 minute
        self.autosave_timer.timeout.connect(self._autosave)
        self.autosave_timer.start()

        self._build_menu()
        self._build_toolbar()
        self._build_ui()
        self._build_status()
        self._update_title()

    def _update_title(self):
        """Update window title with project name and dirty flag."""
        name = Path(self.project_path).stem if self.project_path else "Untitled"
        dirty = " \u2022" if self._dirty or self.canvas._dirty else ""
        self.setWindowTitle(f"Asteron Workbench \u2014 {name}{dirty}")

    def _mark_dirty(self):
        self._dirty = True
        self._update_title()

    def closeEvent(self, event):
        """Warn about unsaved changes before closing."""
        if self._dirty or self.canvas._dirty:
            reply = QMessageBox.question(
                self, "Unsaved Changes",
                "You have unsaved changes. Save before closing?",
                QMessageBox.Save | QMessageBox.Discard | QMessageBox.Cancel,
                QMessageBox.Save)
            if reply == QMessageBox.Save:
                self._save_project()
                event.accept()
            elif reply == QMessageBox.Discard:
                event.accept()
            else:
                event.ignore()
        else:
            event.accept()

    def _autosave(self):
        """Auto-save to temp file for crash recovery."""
        if not (self._dirty or self.canvas._dirty):
            return
        try:
            autosave_dir = Path(tempfile.gettempdir()) / "asteron_workbench"
            autosave_dir.mkdir(exist_ok=True)
            path = autosave_dir / "autosave.awp"
            data = self._build_project_data()
            with open(path, "w", encoding="utf-8") as f:
                json.dump(data, f)
        except Exception:
            pass  # Silently fail auto-save

    def _build_project_data(self):
        """Serialize entire project to a dict."""
        instances = []
        for inst in self.canvas.instances:
            instances.append({
                "dev_id": inst["dev"].id,
                "x": inst["x"], "y": inst["y"],
                "state": inst["state"]
            })
        return {
            "format": "awp", "version": "2.1",
            "code": self.editor.toPlainText(),
            "instances": instances,
            "wires": [{
                "from": w["from"], "to": w["to"],
                "waypoints": w.get("waypoints", [])
            } for w in self.canvas.wires],
            "camera": {"x": self.canvas.camera.x(), "y": self.canvas.camera.y(),
                       "zoom": self.canvas.zoom_level},
            "device_paths": list(self._loaded_paths) if hasattr(self, '_loaded_paths') else []
        }

    def _save_project(self):
        """Save project to .awp file."""
        if not self.project_path:
            return self._save_project_as()
        try:
            data = self._build_project_data()
            with open(self.project_path, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)
            self._dirty = False
            self.canvas._dirty = False
            self._update_title()
            self.serial.log(f"Project saved: {Path(self.project_path).name}", "i")
            self._add_recent(self.project_path)
            return True
        except Exception as ex:
            QMessageBox.warning(self, "Save Error", f"Failed to save:\n{ex}")
            return False

    def _save_project_as(self):
        """Save project with file chooser."""
        path, _ = QFileDialog.getSaveFileName(
            self, "Save Project", "", "Workbench Project (*.awp);;All (*)")
        if not path:
            return False
        self.project_path = path
        return self._save_project()

    def _open_project(self):
        """Open a .awp project file."""
        if self._dirty or self.canvas._dirty:
            reply = QMessageBox.question(
                self, "Unsaved Changes", "Save current project first?",
                QMessageBox.Save | QMessageBox.Discard | QMessageBox.Cancel)
            if reply == QMessageBox.Save:
                if not self._save_project():
                    return
            elif reply == QMessageBox.Cancel:
                return
        path, _ = QFileDialog.getOpenFileName(
            self, "Open Project", "", "Workbench Project (*.awp);;All (*)")
        if not path:
            return
        self._load_project(path)

    def _load_project(self, path):
        """Load a project from .awp file."""
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            # Restore code
            self.editor.setPlainText(data.get("code", ""))
            # Restore instances (need loaded devices)
            self.canvas.instances = []
            self.canvas.wires = []
            for inst_data in data.get("instances", []):
                dev_id = inst_data["dev_id"]
                if dev_id in self.devices:
                    self.canvas.instances.append({
                        "id": _next_id(), "dev": self.devices[dev_id],
                        "x": inst_data["x"], "y": inst_data["y"],
                        "state": inst_data.get("state", {})
                    })
            # Restore wires (re-map IDs)
            for w_data in data.get("wires", []):
                self.canvas.wires.append({
                    "id": _next_id(),
                    "from": tuple(w_data["from"]),
                    "to": tuple(w_data["to"]),
                    "waypoints": w_data.get("waypoints", [])
                })
            # Restore camera
            cam = data.get("camera", {})
            self.canvas.camera = QPointF(cam.get("x", 0), cam.get("y", 0))
            self.canvas.zoom_level = cam.get("zoom", 1.0)

            self.project_path = path
            self._dirty = False
            self.canvas._dirty = False
            self.canvas.undo_stack = UndoStack()
            self.canvas._init_undo()
            self.canvas.update()
            self._update_title()
            self._add_recent(path)
            self.serial.log(f"Opened: {Path(path).name}", "i")
        except Exception as ex:
            QMessageBox.warning(self, "Open Error", f"Failed to open project:\n{ex}")

    def _check_autosave(self):
        """Check for auto-save recovery on startup."""
        autosave = Path(tempfile.gettempdir()) / "asteron_workbench" / "autosave.awp"
        if autosave.exists():
            age = time.time() - autosave.stat().st_mtime
            if age < 3600:  # Less than 1 hour old
                reply = QMessageBox.question(
                    self, "Recover Auto-Save",
                    f"Found auto-saved project ({int(age/60)} min old). Recover it?",
                    QMessageBox.Yes | QMessageBox.No)
                if reply == QMessageBox.Yes:
                    self._load_project(str(autosave))
                    self.project_path = None
                    self._dirty = True
                    self._update_title()

    # ── Recent Files ──
    def _add_recent(self, path):
        """Add a path to recent files list."""
        recents = self.settings.value("recent_files", [], type=list)
        if path in recents:
            recents.remove(path)
        recents.insert(0, path)
        self.settings.setValue("recent_files", recents[:8])
        self._rebuild_recent_menu()

    def _rebuild_recent_menu(self):
        """Rebuild the recent files submenu."""
        self.recent_menu.clear()
        recents = self.settings.value("recent_files", [], type=list)
        if not recents:
            act = self.recent_menu.addAction("(none)")
            act.setEnabled(False)
            return
        for path in recents:
            if Path(path).exists():
                name = Path(path).name
                self.recent_menu.addAction(name, lambda p=path: self._load_project(p))

    # ── UI Build ──
    def _build_menu(self):
        mb = self.menuBar()
        fm = mb.addMenu("&File")
        fm.addAction("New Project", self._new_project, "Ctrl+N")
        fm.addAction("Open Project...", self._open_project, "Ctrl+O")
        fm.addAction("Save Project", self._save_project, "Ctrl+S")
        fm.addAction("Save Project As...", self._save_project_as, "Ctrl+Shift+S")
        fm.addSeparator()
        self.recent_menu = fm.addMenu("Recent Projects")
        self._rebuild_recent_menu()
        fm.addSeparator()
        fm.addAction("Import Sketch...", self._import_code)
        fm.addAction("Import Device Files...", self._import_devices)
        fm.addSeparator()
        fm.addAction("Exit", self.close)

        em = mb.addMenu("&Edit")
        em.addAction("Undo", self._do_undo, "Ctrl+Z")
        em.addAction("Redo", self._do_redo, "Ctrl+Shift+Z")
        em.addSeparator()
        em.addAction("Duplicate", lambda: self.canvas.duplicate_selected(), "Ctrl+D")
        em.addAction("Delete Selected", lambda: self.canvas.delete_selected(), "Delete")
        em.addSeparator()
        em.addAction("Fit All", lambda: self.canvas.fit_all(), "Home")

        sm = mb.addMenu("&Simulation")
        sm.addAction("Run", self._run_sim, "F5")
        sm.addAction("Stop", self._stop_sim, "Shift+F5")

    def _new_project(self):
        """Start a new empty project."""
        if self._dirty or self.canvas._dirty:
            reply = QMessageBox.question(
                self, "Unsaved Changes", "Save current project?",
                QMessageBox.Save | QMessageBox.Discard | QMessageBox.Cancel)
            if reply == QMessageBox.Save:
                if not self._save_project():
                    return
            elif reply == QMessageBox.Cancel:
                return
        self.canvas.instances = []
        self.canvas.wires = []
        self.canvas.selected = None
        self.canvas.connecting = None
        self.canvas.camera = QPointF(0, 0)
        self.canvas.zoom_level = 1.0
        self.canvas.undo_stack = UndoStack()
        self.canvas._init_undo()
        self.canvas._dirty = False
        self.editor.setPlainText("")
        self.project_path = None
        self._dirty = False
        self._update_title()
        self.canvas.update()
        self.serial.log("New project.", "i")

    def _do_undo(self):
        state = self.canvas.undo_stack.undo()
        if state:
            self._restore_canvas_state(state)
            self.serial.log("Undo", "i")

    def _do_redo(self):
        state = self.canvas.undo_stack.redo()
        if state:
            self._restore_canvas_state(state)
            self.serial.log("Redo", "i")

    def _restore_canvas_state(self, state):
        """Restore canvas from an undo state dict."""
        # Rebuild instances from saved state (need device refs)
        new_instances = []
        for inst_data in state["instances"]:
            dev = self.devices.get(inst_data["dev_id"])
            if dev:
                new_instances.append({
                    "id": inst_data["id"], "dev": dev,
                    "x": inst_data["x"], "y": inst_data["y"],
                    "state": inst_data.get("state", dict(dev.state_vars))
                })
        self.canvas.instances = new_instances
        self.canvas.wires = state["wires"]
        self.canvas.selected = None
        self.canvas.update()

    def _build_toolbar(self):
        tb = self.addToolBar("Main")
        tb.setMovable(False)
        logo = QLabel(" ASTERON ")
        logo.setFont(QFont(T.MONO, 12, QFont.Bold))
        logo.setStyleSheet("color:"+T.orange+";letter-spacing:2px;padding-right:8px")
        logo.setToolTip("Asteron Workbench IDE")
        tb.addWidget(logo)
        for c in [T.blue, T.red, T.green, T.orange]:
            d = QLabel("\u25cf")
            d.setFont(QFont(T.MONO, 8))
            d.setStyleSheet("color:" + c)
            tb.addWidget(d)
        sep0 = QFrame()
        sep0.setFrameShape(QFrame.VLine)
        sep0.setStyleSheet("color:" + T.border)
        tb.addWidget(sep0)

        bs = QPushButton("Import Sketch")
        bs.setToolTip("Import an Arduino .ino file (code editor)")
        bs.clicked.connect(self._import_code)
        tb.addWidget(bs)
        bd = QPushButton("Import Devices")
        bd.setToolTip("Import .adev device definition files")
        bd.clicked.connect(self._import_devices)
        tb.addWidget(bd)

        sep1 = QFrame()
        sep1.setFrameShape(QFrame.VLine)
        sep1.setStyleSheet("color:" + T.border)
        tb.addWidget(sep1)

        self.tool_btns = {}
        tool_defs = [
            ("select", "Select [1]", T.blue, "Select and drag components"),
            ("wire", "Wire [2]", T.orange, "Draw wires between pins"),
            ("delete", "Delete [3]", T.red, "Click components or wires to delete")
        ]
        for tid, label, clr, tip in tool_defs:
            b = QPushButton(label)
            b.setCheckable(True)
            b.setChecked(tid == "select")
            b.setToolTip(tip)
            dm = {T.blue: T.blueDim, T.red: T.redDim, T.orange: T.orangeDim}.get(clr, T.blueDim)
            b.setStyleSheet(
                "QPushButton{background:"+T.surface+";color:"+T.text+";"
                "border:1px solid "+T.border+";border-radius:4px;padding:6px 14px;font-weight:bold}"
                "QPushButton:hover{border-color:"+clr+"}"
                "QPushButton:checked{background:"+dm+";border-color:"+clr+";color:"+clr+"}")
            b.clicked.connect(lambda _, t=tid: self._set_tool(t))
            tb.addWidget(b)
            self.tool_btns[tid] = b

        sep2 = QFrame()
        sep2.setFrameShape(QFrame.VLine)
        sep2.setStyleSheet("color:" + T.border)
        tb.addWidget(sep2)

        self.btn_run = QPushButton("\u25b6 Run")
        self.btn_run.setToolTip("Start simulation (F5)")
        self.btn_run.setStyleSheet(
            "QPushButton{background:"+T.green+";color:#000;border:none;"
            "border-radius:4px;padding:6px 16px;font-weight:bold}"
            "QPushButton:hover{background:#55ee77}")
        self.btn_run.clicked.connect(self._run_sim)
        tb.addWidget(self.btn_run)

        self.btn_stop = QPushButton("\u25a0 Stop")
        self.btn_stop.setToolTip("Stop simulation (Shift+F5)")
        self.btn_stop.setStyleSheet(
            "QPushButton{background:"+T.red+";color:#fff;border:none;"
            "border-radius:4px;padding:6px 16px;font-weight:bold}"
            "QPushButton:hover{background:#ff6666}")
        self.btn_stop.clicked.connect(self._stop_sim)
        self.btn_stop.setEnabled(False)
        tb.addWidget(self.btn_stop)

        spacer = QWidget()
        spacer.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        tb.addWidget(spacer)

        self.lbl_status = QLabel("IDLE")
        self.lbl_status.setFont(QFont(T.MONO, 10))
        self.lbl_status.setStyleSheet("color:"+T.textMut+";padding:0 12px")
        tb.addWidget(self.lbl_status)

    def _set_tool(self, tid):
        self.canvas.tool = tid
        self.canvas.connecting = None
        self.canvas.wire_points = []
        self.canvas.update()
        for k, b in self.tool_btns.items():
            b.setChecked(k == tid)

    def _build_ui(self):
        cw = QWidget()
        self.setCentralWidget(cw)
        ml = QHBoxLayout(cw)
        ml.setContentsMargins(0, 0, 0, 0)
        ml.setSpacing(0)
        sp = QSplitter(Qt.Horizontal)

        # Left panel — device library
        left = QWidget()
        ll = QVBoxLayout(left)
        ll.setContentsMargins(0, 0, 0, 0)
        ll.setSpacing(0)

        lib = QLabel("  DEVICES")
        lib.setFont(QFont(T.MONO, 9, QFont.Bold))
        lib.setStyleSheet("color:"+T.textMut+";padding:10px 4px 6px;letter-spacing:2px")
        ll.addWidget(lib)

        self.dev_tree = QTreeWidget()
        self.dev_tree.setHeaderHidden(True)
        self.dev_tree.setRootIsDecorated(True)
        self.dev_tree.setIndentation(14)
        self.dev_tree.setToolTip("Click a device to place it on the canvas")
        self.dev_tree.itemClicked.connect(self._on_dev_click)
        ll.addWidget(self.dev_tree)

        tip = QLabel(
            "Click device = place\nDel = remove\nScroll = zoom\n"
            "Middle-click = pan\nHome = fit all\n\n"
            "WIRING:\nClick pin = start wire\nRight-click = waypoint\n"
            "Click target pin = finish\nEsc = cancel wire\n\n"
            "Ctrl+Z/Shift+Z = undo/redo\nCtrl+D = duplicate\nCtrl+S = save"
        )
        tip.setFont(QFont(T.UI, 9))
        tip.setStyleSheet("color:"+T.textMut+";padding:10px;border-top:1px solid "+T.border)
        tip.setWordWrap(True)
        ll.addWidget(tip)

        self.dev_count_lbl = QLabel("  0 devices loaded")
        self.dev_count_lbl.setFont(QFont(T.MONO, 8))
        self.dev_count_lbl.setStyleSheet("color:"+T.textMut+";padding:4px 8px")
        ll.addWidget(self.dev_count_lbl)

        left.setMaximumWidth(200)
        left.setMinimumWidth(150)
        sp.addWidget(left)

        # Center — canvas + bottom tabs
        cs = QSplitter(Qt.Vertical)
        self.canvas = CircuitCanvas()
        self.canvas.selectionChanged.connect(self._on_select)
        cs.addWidget(self.canvas)

        self.btabs = QTabWidget()
        self.serial = SerialMonitor()
        self.btabs.addTab(self.serial, "Serial Monitor")

        self.problems = QTextEdit()
        self.problems.setReadOnly(True)
        self.problems.setStyleSheet("background:"+T.bg+";color:"+T.textMut+";border:none")
        self.problems.setPlainText("No problems detected.")
        self.btabs.addTab(self.problems, "Problems")
        cs.addWidget(self.btabs)
        cs.setSizes([500, 140])
        sp.addWidget(cs)

        # Right — code editor + properties
        right = QWidget()
        rl = QVBoxLayout(right)
        rl.setContentsMargins(0, 0, 0, 0)
        rl.setSpacing(0)
        self.rtabs = QTabWidget()
        self.editor = CodeEditor()
        self.editor.setPlaceholderText("Import a .ino sketch or type code here...")
        self.editor.textChanged.connect(self._mark_dirty)
        self.rtabs.addTab(self.editor, "sketch.ino")

        self.props_panel = QTextEdit()
        self.props_panel.setReadOnly(True)
        self.props_panel.setStyleSheet(
            "background:"+T.bg+";color:"+T.textSec+";border:none;padding:14px")
        self.props_panel.setFont(QFont(T.MONO, 11))
        self.props_panel.setPlainText("Select a component to view properties.")
        self.rtabs.addTab(self.props_panel, "Properties")
        rl.addWidget(self.rtabs)
        right.setMinimumWidth(300)
        sp.addWidget(right)
        sp.setSizes([180, 700, 380])
        ml.addWidget(sp)

    def _build_status(self):
        sb = self.statusBar()
        self.st_sim = QLabel("IDLE")
        self.st_parts = QLabel("0 parts | 0 wires")
        self.st_devs = QLabel("0 devices")
        for lbl in [self.st_sim, self.st_parts, self.st_devs]:
            lbl.setFont(QFont(T.MONO, 10))
            lbl.setStyleSheet("color:"+T.textMut+";padding:0 10px")
            sb.addWidget(lbl)
        self.ui_timer = QTimer()
        self.ui_timer.setInterval(500)
        self.ui_timer.timeout.connect(self._update_status)
        self.ui_timer.start()

    def _update_status(self):
        n = len(self.canvas.instances)
        w = len(self.canvas.wires)
        self.st_parts.setText(f"{n} parts | {w} wires")
        self.st_devs.setText(f"{len(self.devices)} devices")
        running = self.canvas.sim_running
        self.st_sim.setText("SIM RUNNING" if running else "IDLE")
        self.st_sim.setStyleSheet(
            "color:" + (T.green if running else T.textMut) + ";padding:0 10px")
        self._update_title()

    def _import_devices(self):
        files, _ = QFileDialog.getOpenFileNames(
            self, "Import Device Files", "", "Device Files (*.adev *.json);;All (*)")
        if not files:
            return
        if not hasattr(self, '_loaded_paths'):
            self._loaded_paths = set()
        count = 0
        for f in files:
            try:
                with open(f, "r", encoding="utf-8") as fh:
                    data = json.load(fh)
                dev = DeviceDef(data)
                self.devices[dev.id] = dev
                self._loaded_paths.add(f)
                count += 1
            except Exception as ex:
                self.serial.log(f"Error loading {Path(f).name}: {ex}", "e")
        self._rebuild_tree()
        self.serial.log(f"Loaded {count} device(s).", "i")
        self.dev_count_lbl.setText(f"  {len(self.devices)} devices loaded")

    def _import_code(self):
        f, _ = QFileDialog.getOpenFileName(
            self, "Import Sketch", "", "Arduino (*.ino *.c *.cpp *.txt);;All (*)")
        if not f:
            return
        try:
            with open(f, "r", encoding="utf-8") as fh:
                self.editor.setPlainText(fh.read())
            self.rtabs.setTabText(0, Path(f).name)
            self.serial.log(f"Loaded sketch: {Path(f).name}", "i")
        except Exception as ex:
            QMessageBox.warning(self, "Error", f"Failed to load sketch:\n{ex}")

    def _rebuild_tree(self):
        self.dev_tree.clear()
        cats = {}
        cat_order = ["Boards", "Output", "Display", "Input", "Sensor", "Passive", "Other"]
        for d in self.devices.values():
            c = d.category or "Other"
            cats.setdefault(c, []).append(d)
        for cat in cat_order + [c for c in cats if c not in cat_order]:
            if cat not in cats:
                continue
            ci = QTreeWidgetItem(self.dev_tree, [cat])
            ci.setFlags(Qt.ItemIsEnabled)
            f = ci.font(0)
            f.setPointSize(10)
            f.setBold(True)
            ci.setFont(0, f)
            ci.setForeground(0, QColor(T.textMut))
            for d in cats[cat]:
                ch = QTreeWidgetItem(ci, [d.name])
                ch.setData(0, Qt.UserRole, d.id)
                pm = QPixmap(10, 10)
                pm.fill(QColor(d.color))
                ch.setIcon(0, QIcon(pm))
                ch.setToolTip(0, d.desc or f"{d.name} ({d.category})")
            ci.setExpanded(True)

    def _on_dev_click(self, item, col):
        did = item.data(0, Qt.UserRole)
        if did and did in self.devices:
            self.canvas.add_instance(self.devices[did])

    def _on_select(self, inst):
        """Update properties panel with formatted component info."""
        if not inst:
            self.props_panel.setPlainText("Select a component to view properties.")
            return
        dev = inst["dev"]
        # Build rich-text properties
        html = f'<h3 style="color:{T.orange}">{dev.name}</h3>'
        html += f'<p style="color:{T.textMut}">{dev.desc}</p>' if dev.desc else ""
        html += f'<p><span style="color:{T.textMut}">ID:</span> {dev.id}<br>'
        html += f'<span style="color:{T.textMut}">Category:</span> {dev.category}<br>'
        html += f'<span style="color:{T.textMut}">Type:</span> {dev.emu_type}<br>'
        html += f'<span style="color:{T.textMut}">Size:</span> {dev.w} \u00d7 {dev.h}</p>'
        html += f'<h4 style="color:{T.green}">PINS ({len(dev.pins)})</h4>'
        for pin in dev.pins:
            pc = PIN_CLR.get(pin.type, T.textSec)
            html += f'<span style="color:{pc}">\u25cf</span> '
            html += f'<b>{pin.label}</b> <span style="color:{T.textMut}">{pin.type} {pin.side}</span><br>'
        if dev.props:
            html += f'<h4 style="color:{T.blue}">PROPERTIES</h4>'
            for k, v in dev.props.items():
                html += f'<span style="color:{T.textMut}">{k}:</span> {v}<br>'
        if dev.leds:
            html += f'<h4 style="color:{T.red}">LED INDICATORS ({len(dev.leds)})</h4>'
            for led in dev.leds:
                html += f'\u25cf {led.get("label","?")} \u2192 {led.get("state_var","?")}<br>'
        self.props_panel.setHtml(html)

    def _run_sim(self):
        code = self.editor.toPlainText()
        if not code.strip():
            self.serial.log("No sketch loaded.", "e")
            return
        self.serial.clear()
        self.serial.log("--- Compiling... ---", "i")
        # Basic validation
        warnings = []
        if "void setup()" not in code:
            warnings.append("Warning: missing setup()")
        if "void loop()" not in code:
            warnings.append("Warning: missing loop()")
        if code.count("{") != code.count("}"):
            warnings.append("Warning: mismatched braces")
        for w in warnings:
            self.serial.log(w, "e")
        self.problems.setPlainText("\n".join(warnings) if warnings else "No problems detected.")

        sz = len(code.encode()) * 2
        self.serial.log(f"Sketch uses ~{sz} bytes ({sz*100//32768}% of storage).", "i")
        self.serial.log("--- Simulation started ---", "i")

        # Extract Serial.print outputs
        for idx, m in enumerate(re.finditer(r'Serial\.println?\(\s*"([^"]+)"\s*\)', code)):
            text = m.group(1)
            QTimer.singleShot(600 * (1 + idx), lambda t=text: self.serial.log_out(t))

        self.canvas.sim_running = True
        self.sim_tick_count = 0
        self.sim_timer.start()
        self.btn_run.setEnabled(False)
        self.btn_stop.setEnabled(True)
        self.lbl_status.setText("RUNNING")
        self.lbl_status.setStyleSheet("color:"+T.green+";padding:0 12px")
        self._has_dw = "digitalWrite" in code
        self._has_blink = self._has_dw and "delay(" in code

    def _stop_sim(self):
        self.canvas.sim_running = False
        self.sim_timer.stop()
        for inst in self.canvas.instances:
            inst["state"] = dict(inst["dev"].state_vars)
        self.canvas.update()
        self.btn_run.setEnabled(True)
        self.btn_stop.setEnabled(False)
        self.lbl_status.setText("IDLE")
        self.lbl_status.setStyleSheet("color:"+T.textMut+";padding:0 12px")
        self.serial.log("--- Simulation stopped ---", "i")

    def _sim_tick(self):
        self.sim_tick_count += 1
        for inst in self.canvas.instances:
            dev = inst["dev"]
            for rule in dev.rules:
                if rule.get("action") == "set_state" and rule.get("target"):
                    if rule.get("trigger") == "pin_high":
                        if self._has_blink:
                            val = rule["value"]
                            if isinstance(val, bool):
                                inst["state"][rule["target"]] = val if self.sim_tick_count % 2 == 0 else (not val)
                            else:
                                inst["state"][rule["target"]] = val if self.sim_tick_count % 2 == 0 else 0
                        elif self._has_dw:
                            inst["state"][rule["target"]] = rule["value"]
        self.canvas.update()

    def keyPressEvent(self, event):
        if event.text() == "1":
            self._set_tool("select")
        elif event.text() == "2":
            self._set_tool("wire")
        elif event.text() == "3":
            self._set_tool("delete")
        else:
            super().keyPressEvent(event)


# ═══════════════════ MAIN ═══════════════════
def main():
    app = QApplication(sys.argv)
    app.setStyle("Fusion")

    # Resolve platform fonts
    T.MONO = _mono_font()
    T.UI = _ui_font()

    pal = QPalette()
    pal.setColor(QPalette.Window, QColor(T.bg))
    pal.setColor(QPalette.WindowText, QColor(T.text))
    pal.setColor(QPalette.Base, QColor(T.panel))
    pal.setColor(QPalette.Text, QColor(T.text))
    pal.setColor(QPalette.Button, QColor(T.panel))
    pal.setColor(QPalette.ButtonText, QColor(T.text))
    pal.setColor(QPalette.Highlight, QColor(T.blue))
    pal.setColor(QPalette.HighlightedText, QColor("#000"))
    app.setPalette(pal)

    win = WorkbenchIDE()
    win.show()
    # Check for crash recovery after window is visible
    QTimer.singleShot(500, win._check_autosave)
    sys.exit(app.exec_())

if __name__ == "__main__":
    main()
